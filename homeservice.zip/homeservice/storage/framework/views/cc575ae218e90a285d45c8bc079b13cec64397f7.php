<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
            <div class="col-md-3">
                <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        <div class="col-md-9">
        <?php else: ?>
        <div class="col-md-12">
        <?php endif; ?>
            <div class="card">
              <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                <?php echo e(Form::open(['url' => '/orders', 'method' => 'get', 'style' => 'width:100%', 'class' => 'mt-3 ml-3'])); ?>

                <fieldset class="search">
                    <div class="form-group row" style="line-height:35px">
                      <div class="col-md-3">
                        Type <?php echo Form::select('type', [0 => 'All', 1 => 'Products', 2 => 'Services'], $type, ['class' => 'form-control m-bot15 float-right', 'id' => 'cat', 'style' => 'width:auto']); ?>

                      </div>
                      <div class="col-md-5">
                        Status <?php echo Form::select('status', ['11' => 'All', 1 => 'Order placed', 2 => 'Shipped', 3 => 'Delivered', 0 => 'Worker notification sent', 7 => 'Worker confirmed order',
                            8 => 'User requested refund',
                            9 => 'Worker requested payment',
                            10 => 'Refunded', 4 => 'Invoice generated', 5 => 'Completed'], $status, ['class' => 'form-control m-bot15 float-right', 'id' => 'cat', 'style' => 'width:auto']); ?>

                      </div>
                      <?php echo e(Form::submit('Search', array('class' => 'btn btn-primary'))); ?>

                    </div>
                </fieldset>
                <?php echo e(Form::close()); ?>

              <?php endif; ?>
                <div class="card-header">
                  <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                  <?php else: ?>
                    My
                  <?php endif; ?>
                    Orders
                </div>

                <div class="card-body">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?> 
                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          <th scope="col">#ID</th>
                          <th scope="col">Name</th>
                          <th scope="col">Date</th>
                          <th scope="col">Shipping Address</th>
                          <th scope="col">Service Address</th>
                          <th scope="col">Amount</th>
                        </tr>
                      </thead>
                      <tbody>                        
                          <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td>
                              <a href="<?php echo e(URL::to('order-details/' . $order->id)); ?>">#<?php echo e(str_pad($order->id, 4, '0', STR_PAD_LEFT)); ?></a>
                            </td>
                            <td>
                              <?php echo e(ucfirst($order->user->name)); ?>

                            </td>
                            <td>
                              <?php echo e(date('d-m-Y', strtotime($order->created_at))); ?>

                            </td>
                            <td>
                              <?php echo ($order->shipping_address)?nl2br($order->shipping_address):'--'; ?>  
                            </td>
                            <td>
                              <?php echo ($order->service_addr)?nl2br($order->service_addr):'--'; ?>  
                            </td>
                            <td><?php echo config('app.currency'); ?><?php echo e(number_format($order->amount, 2)); ?></td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php if(!count($orders)): ?>
                            <tr class="no-rec">
                              <td colspan="6">No records!</td>
                            </tr>
                          <?php endif; ?>
                        </tbody>
                    </table>
                  <?php echo $orders->appends(\Request::except('page'))->render(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
$(function(){
  setTimeout(function() {
                $('select[name="type"]').trigger('change');
            }, 100);

  $('select[name="type"]').change(function(){
    $('select[name="status"] option').removeAttr('disabled')
    if($('select[name="type"]').val() == '1'){
      $('select[name="status"] option[value="0"]').attr('disabled', 'disabled')
      $('select[name="status"] option[value="4"]').attr('disabled', 'disabled')
      $('select[name="status"] option[value="5"]').attr('disabled', 'disabled')
      $('select[name="status"] option[value="7"]').attr('disabled', 'disabled')
      $('select[name="status"] option[value="8"]').attr('disabled', 'disabled')
      $('select[name="status"] option[value="9"]').attr('disabled', 'disabled')
      $('select[name="status"] option[value="10"]').attr('disabled', 'disabled')
    } else if($('select[name="type"]').val() == '2'){
      $('select[name="status"] option[value="2"]').attr('disabled', 'disabled')
      $('select[name="status"] option[value="3"]').attr('disabled', 'disabled')
    }
  })  
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>