<?php $__env->startSection('title', '| Edit Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-12">

			<?php echo e(Form::open(['url' => '/shop', 'method' => 'get', 'style' => 'width:100%'])); ?>

			<fieldset class="search">
				  <div class="form-group row">
			    <div class="col-md-3">
			      <?php echo e(Form::text('keyword', $keyword, array('class' => 'form-control', 'id' => 'keyword', 'placeholder' => 'Product name or description'))); ?>

			    </div>
			  	<div class="col-md-3">
			    	<?php echo Form::select('cat', $prodCats, $cat, ['class' => 'form-control m-bot15', 'placeholder' => 'Category', 'id' => 'cat']); ?>

			  	</div>
			  	<?php echo e(Form::submit('Search', array('class' => 'btn btn-primary'))); ?>

			  </div>
			</fieldset>
			<?php echo e(Form::close()); ?>

            

            <h1>Products</h1>
            <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	<div class="col-md-3 singleProd">
            	  <div class="w-100 prod-list-img">
					  <?php if(!empty($product->img)): ?>
		                  <img class="img-responsive" src="<?php echo e(URL::asset('images/products')); ?>/<?php echo e($product->img); ?>" >
		              <?php else: ?>
		                  <img class="img-responsive" src="<?php echo e(URL::asset('images/products')); ?>/214x150.png" >
		              <?php endif; ?>
		          </div>  
				  <div class="product-short">
				    <h5 class="prod-title">
				    	<a href="<?php echo e(URL::to('product/' .  Str::slug($product->name) . '/' . $product->id)); ?>">
				    		<?php echo e($product->name); ?>

				    	</a>
				    </h5>
				    <h6 class="prod-desc"><?php echo e(ucfirst((strlen($product->description) > 70)?substr($product->description, 0, 70).'...':$product->description)); ?></h6>
				    <div class="row addToCart">
				    	<?php if($product->qty): ?>
					    	<div class="prod-amount col"><?php echo config('app.currency'); ?><?php echo e(number_format($product->amount, 2)); ?></div>
					    	<?php echo e(Form::open(array('url' => 'cart/' . $product->id, 'class' => 'col-md-8'))); ?>

	                          <?php echo e(Form::hidden('_method', 'POST')); ?>

	                          <?php echo Form::select('qty'.$product->id, array(1 => 1, 2 => 2, 3 => 3, 4 => 4, 5 => 5), Request::old('qty'), ['class' => $errors->has('qty'.$product->id) ? 'form-control float-left is-invalid' : 'form-control float-left', $errors->has('qty'.$product->id)?'autofocus':'']); ?>

                              <?php echo e(Form::submit('Add to cart', array('class' => 'btn btn-primary form-inline', (session('success'.$product->id))?'autofocus':''))); ?>

                              <span class="invalid-feedback mt-2 w-100" role="alert">
	                                <strong><?php echo e($errors->first('qty'.$product->id)); ?></strong>
	                          </span>
	                        <?php echo e(Form::close()); ?>

                            <?php if(session('success'.$product->id)): ?>
						        <div class="alert alert-success ml-3 mr-3 mt-2 w-100">
						            <?php echo e(session('success'.$product->id)); ?>

						        </div>
						    <?php endif; ?>
	                    <?php else: ?>
	                    	<div class="col-md-12 out-of-stock">Out of stock</div>
	                    <?php endif; ?>
				    </div>
				  </div>
				</div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(!count($products)): ?>
	            <div class="col-md-12">
	            	No products found!
	            </div>
            <?php else: ?>
            	<div class="col-md-12">
            		<?php echo $products->appends(\Request::except('page'))->render(); ?>

            	</div>
            <?php endif; ?>
          	</div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>