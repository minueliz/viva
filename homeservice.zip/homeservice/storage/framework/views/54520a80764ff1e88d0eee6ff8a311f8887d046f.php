<?php $__env->startSection('title', '| Create New Event'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">
                  Product Details                  
                </div>

                <div class="card-body">

                  <div class="form-group row">
                      <?php echo e(Form::label('name', 'Name', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                      <div class="col-md-4">
                        <?php echo e($product->name); ?>

                      </div>
                  </div>
                  <div class="form-group row">
                      <?php echo e(Form::label('description', 'Description', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                      <div class="col-md-4">
                        <?php echo nl2br($product->description); ?>

                      </div>
                  </div>

                  <div class="form-group row">
                      <?php echo e(Form::label('cat', 'Category', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                      <div class="col-md-4">
                        <?php echo e($product->category->category); ?>

                      </div>
                  </div>

                  <div class="form-group row">
                      <?php echo e(Form::label('qty', 'Quantity', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                      <div class="col-md-4">
                        <?php echo e($product->qty); ?>

                      </div>
                  </div>

                  <div class="form-group row">
                      <?php echo e(Form::label('amount', 'Amount', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                      <div class="col-md-4">
                        <?php echo e(number_format($product->amount, 2)); ?>

                      </div>
                  </div>

                  <?php if(!empty($product->img)): ?>
                    <div class="form-group row offset-md-4">
                      <div class="col-md-4">
                        <img class="profilepic" src="<?php echo e(URL::asset('images/products')); ?>/<?php echo e($product->img); ?>">
                      </div>
                    </div>
                  <?php endif; ?>         

                </div>
            </div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>