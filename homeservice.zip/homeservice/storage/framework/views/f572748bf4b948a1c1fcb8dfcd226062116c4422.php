<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Security Questions</div>

                <div class="card-body">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?> 
                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          <th scope="col">Name</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>                        
                          <?php $__currentLoopData = $sec_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec_question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td>
                                <?php echo e($sec_question->question); ?>

                              </td>
                              <td>
                                <a class="btn btn-sm btn-info edit-btn" href="<?php echo e(URL::to('security-questions/' . $sec_question->id . '/edit')); ?>">Edit</a>
                                <?php echo e(Form::open(array('url' => 'security-questions/disable/' . $sec_question->id, 'class' => 'pull-right'))); ?>

                                    <?php echo e(Form::hidden('_method', 'POST')); ?>

                                    
                                        <?php echo e(Form::submit(($sec_question->status)?'Disable':'Enable', array('class' => ($sec_question->status)?'btn btn-sm btn-warning':'btn btn-sm btn-primary'))); ?>


                                  <?php echo e(Form::close()); ?>                                
                              </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php if(!count($sec_questions)): ?>
                            <tr class="no-rec">
                              <td colspan="2">No records!</td>
                            </tr>
                          <?php endif; ?>
                        </tbody>
                    </table>
                  <?php echo $sec_questions->appends(\Request::except('page'))->render(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>