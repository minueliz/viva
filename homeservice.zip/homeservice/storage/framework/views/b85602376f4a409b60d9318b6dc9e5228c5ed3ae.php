<?php $__env->startComponent('mail::message'); ?>
Dear <?php echo e($name); ?>,

User <b><?php echo e($details['custName']); ?></b> has ordered your service <a href="<?php echo e(URL::to('service-requests/'. $details['item_id'])); ?> }}">#<?php echo e($details['item_id']); ?></a>. Find below the details,<br>
Date: <?php echo e($details['bDate']); ?><br>
Category: <?php echo e($details['catName']); ?><br>
Subcategory: <?php echo e($details['subCatName']); ?><br>
Slot: <?php echo e($details['slotName']); ?><br>
Description: <?php echo nl2br($details['desc']); ?><br>
Image: <img src="<?php echo e(URL::asset('images/serv')); ?>/<?php echo e($details['img']); ?>"><br><br>
<b>PS: You have to respond by confirming or declining the request within a day, otherwise the request will be cancelled automatically.<b>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>