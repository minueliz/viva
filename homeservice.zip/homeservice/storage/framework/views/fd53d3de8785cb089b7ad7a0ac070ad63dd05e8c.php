<nav class="navbar navbar-expand-md side-navbar">
    <div class="container">        
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContentSub" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContentSub">
            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav">
                <!-- Authentication Links -->
                <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('admin')); ?>"><?php echo e(__('Dashboard')); ?></a>
                    </li>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(__('Users')); ?> <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(url('admin/users')); ?>">
                                <?php echo e(__('Customers')); ?>

                            </a>

                            <a class="dropdown-item" href="<?php echo e(url('admin/workers')); ?>">
                                <?php echo e(__('Workers')); ?>

                            </a>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(__('Products')); ?> <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(url('products')); ?>">
                                <?php echo e(__('List')); ?>

                            </a>

                            <a class="dropdown-item" href="<?php echo e(url('products/create')); ?>">
                                <?php echo e(__('Add')); ?>

                            </a>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(__('Product Categories')); ?> <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(url('product-categories')); ?>">
                                <?php echo e(__('List')); ?>

                            </a>

                            <a class="dropdown-item" href="<?php echo e(url('product-categories/create')); ?>">
                                <?php echo e(__('Add')); ?>

                            </a>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(__('Service Categories')); ?> <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(url('service-categories')); ?>">
                                <?php echo e(__('List Categories')); ?>

                            </a>

                            <a class="dropdown-item" href="<?php echo e(url('service-categories/create')); ?>">
                                <?php echo e(__('Add Category')); ?>

                            </a>
                            <a class="dropdown-item" href="<?php echo e(url('service-categories/subcategories/list')); ?>">
                                <?php echo e(__('List Subcategories')); ?>

                            </a>

                            <a class="dropdown-item" href="<?php echo e(url('service-categories/create/sub')); ?>">
                                <?php echo e(__('Add Subategory')); ?>

                            </a>
                        </div>
                    </li>
                    <!-- <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('service-slots')); ?>">
                            <?php echo e(__('Service Slots')); ?>

                        </a>
                    </li> -->
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(__('Districts')); ?> <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(url('districts')); ?>">
                                <?php echo e(__('List')); ?>

                            </a>

                            <a class="dropdown-item" href="<?php echo e(url('districts/create')); ?>">
                                <?php echo e(__('Add')); ?>

                            </a>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(__('Security Questions')); ?> <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(url('security-questions')); ?>">
                                <?php echo e(__('List')); ?>

                            </a>

                            <a class="dropdown-item" href="<?php echo e(url('security-questions/create')); ?>">
                                <?php echo e(__('Add')); ?>

                            </a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('orders')); ?>">
                            <?php echo e(__('Orders')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('reviews')); ?>">
                            <?php echo e(__('Reviews')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('leaves')); ?>">
                            <?php echo e(__('Leaves')); ?>

                            <?php if($leaveCount): ?>
                                <span class="fa-stack fa-1x has-badge" data-count="<?php echo e($leaveCount); ?>">
                                    <i class="fa fa-circle fa-stack-2x"></i>
                                    <i class="fa fa-bell fa-stack-1x fa-inverse"></i>
                                </span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('commission')); ?>">
                            <?php echo e(__('Commission')); ?>

                        </a>
                    </li>
                <?php endif; ?>  
            </ul>
        </div>
    </div>
</nav>