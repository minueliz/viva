<?php $__env->startComponent('mail::message'); ?>
Dear <?php echo e($name); ?>,

User <b><?php echo e($service->order->user->name); ?></b> has cancelled the order, #<b><a href="<?php echo e(URL::to('service-requests/' . $service->id)); ?>"><?php echo e($service->id); ?></a></b>. 

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>