<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Service Slots</div>

                <div class="card-body">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?> 
                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          <th scope="col">Slot</th>
                          <th scope="col" width="244px">Action</th>
                        </tr>
                      </thead>
                      <tbody>                        
                          <?php $__currentLoopData = $serviceSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($slot->slot); ?></td>
                              <td>
                                <a class="btn btn-sm btn-info approve-btn edit-btn" href="<?php echo e(URL::to('service-slots/' . $slot->id . '/edit')); ?>">Edit</a>
                                <?php echo e(Form::open(array('url' => 'service-slots/disable/' . $slot->id, 'class' => 'pull-right'))); ?>

                                    <?php echo e(Form::hidden('_method', 'POST')); ?>

                                    
                                        <?php echo e(Form::submit(($slot->status)?'Disable':'Enable', array('class' => ($slot->status)?'btn btn-sm btn-warning':'btn btn-sm btn-primary'))); ?>


                                  <?php echo e(Form::close()); ?>                                
                              </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php if(!count($serviceSlots)): ?>
                            <tr class="no-rec">
                              <td colspan="5">No records!</td>
                            </tr>
                          <?php endif; ?>
                        </tbody>
                    </table>
                  <?php echo $serviceSlots->appends(\Request::except('page'))->render(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>