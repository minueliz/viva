<?php $__env->startSection('title', '| Edit Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-12">
            <div class="booking-form">
				<?php echo e(Form::open(array('url' => '/services', 'method' => 'get', 'class' => "reviewForm"))); ?>

					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<span class="form-label">Category</span>
								<?php echo Form::select('cat', $serviceCats, $cat, ['class' => 'form-control required']); ?>

								<span class="select-arrow"></span>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<span class="form-label">Subcategory</span>
								<?php echo Form::select('subCat', $subCats, $subCat, ['class' => 'form-control required']); ?>

								<span class="select-arrow"></span>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<span class="form-label">Date</span>
								<?php echo e(Form::text('bDate', $bDate, array('class' => 'form-control required', 'id' => 'bDate', 'placeholder' => 'mm/dd/yyyy'))); ?>

							</div>
						</div>
						<div style="width:132px" class="pr-3">
							<div class="form-group">
								<span class="form-label">From</span>
								<?php echo Form::select('slotFrom', $hours, $_slotFrom, ['class' => 'form-control required']); ?>

								<span class="select-arrow"></span>
							</div>
						</div>
						<div style="width:115px">
							<div class="form-group">
								<span class="form-label">To</span>
								<?php echo Form::select('slotTo', $hours, $_slotTo, ['class' => 'form-control required']); ?>

								<span class="select-arrow"></span>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-btn">
								<button class="submit-btn">Search</button>
							</div>
						</div>
					</div>
				<?php echo e(Form::close()); ?>

			</div>
			<div class="mt-4">
				
				<h1>Services</h1>
				
	            <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wKey => $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	            <?php echo e(Form::open(array('url' => 'cart/' . $worker->id, 'class' => '', 'enctype' => "multipart/form-data" ))); ?>

		        	<div class="row mb-3">
	            	  <div class="col-md-3 service-list-img">
						  <?php if(!empty($worker->userinformation->img)): ?>
			                  <img class="img-responsive" src="<?php echo e(URL::asset('images/profile')); ?>/<?php echo e($worker->userinformation->img); ?>" >
			              <?php elseif(!empty($worker->userinformation->category->img)): ?>
			                  <img src="<?php echo e(URL::asset('images/service-categories')); ?>/<?php echo e($worker->userinformation->category->img); ?>" >
			              <?php else: ?>
			              	<img src="<?php echo e(URL::asset('images/service-categories')); ?>/214x150.png" >
			              <?php endif; ?>
			          </div>  
					  <div class="col-md-3">
					    <h5 class="prod-title text-left">
					    	<?php echo e($worker->name); ?>

					    </h5>
					    <?php if($worker->reviews->avg('rating')): ?>
					    	Rating: 
							<?php for($i=1; $i<=$worker->reviews->avg('rating'); $i++): ?>
								<span class="fas fa-star" aria-hidden="true"></span>
							<?php endfor; ?>
							<?php for($i=$worker->reviews->avg('rating'); $i<5; $i++): ?>
								<span class="far fa-star" aria-hidden="true"></span>
							<?php endfor; ?>
						<?php endif; ?>

						<div>Per hour charge: <?php echo config('app.currency'); ?><?php echo e($worker->userinformation->per_hour_amount); ?></div>
												
                          <?php echo e(Form::hidden('_method', 'POST')); ?>

                          <?php echo e(Form::hidden('_type', 'service')); ?>

                          <?php echo e(Form::hidden('_cat', $cat)); ?>

                          <?php echo e(Form::hidden('_subCat', $subCat)); ?>

                          <?php echo e(Form::hidden('_slotFrom', $_slotFrom)); ?>

                          <?php echo e(Form::hidden('_slotTo', $_slotTo)); ?>

                          <?php echo e(Form::hidden('_bDate', $bDate)); ?>

                          <a href="#collapse<?php echo e($wKey); ?>" class="btn btn-primary" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="collapse<?php echo e($wKey); ?>">Book</a>
                       	
                       	 <?php if(session('success'.$worker->id)): ?>
					        <div class="alert alert-success mt-2 w-100">
					            <?php echo e(session('success'.$worker->id)); ?>

					        </div>
					    <?php endif; ?>
					    <span class="invalid-feedback w-100 d-block" role="alert">
                            <strong><?php echo e($errors->first('id'.$worker->id)); ?></strong>
                      	</span>
					  </div>
					  <?php if(count($worker->reviews)): ?>
					  <div class="col-md-6 review-con">
					  	<div class="review-con-inner">
				 		<?php $__currentLoopData = $worker->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				 			<?php if($review->status	== 0): ?> <?php continue; ?>; <?php endif; ?>
						  	<div class="col-md-12 <?php echo e((($key+1) < count($worker->reviews)) ? 'border-bottom' : ''); ?> mb-2">
						  		<div class="row mb-3">
				        	    <div class="col-md-2">
				        	        <?php if(!empty($review->user->userinformation->img)): ?>
				                        <div class="inset">
				                          <img src="<?php echo e(URL::asset('images/profile')); ?>/<?php echo e($review->user->userinformation->img); ?>">
				                        </div>
				                    <?php else: ?>
				        	        	<img src="<?php echo e(URL::asset('images/profile')); ?>/214x150.png" class="img img-rounded img-fluid"/>
				                    <?php endif; ?>
				        	        <!-- <p class="text-secondary text-center">15 Minutes Ago</p> -->
				        	    </div>
				        	    <div class="col-md-10">
				        	        <p>
				        	            <a class="float-left namel" href="#"><strong><?php echo e(ucfirst($review->user->name)); ?></strong></a>
				        	            <?php for($i=$review->rating; $i<5; $i++): ?>
											<span class="float-right"><span class="text-warning far fa-star" aria-hidden="true"></span></span>
										<?php endfor; ?>
				        	            <?php for($i=1; $i<=$review->rating; $i++): ?>
									  		<span class="float-right"><i class="text-warning fa fa-star"></i></span>
										<?php endfor; ?>
				        	       </p>
				        	       <div class="clearfix"></div>
				        	        <p><?php echo e($review->comment); ?></p>
				        	    </div>
				        	    </div>
					        </div>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					    </div>
					  </div>
				    <?php else: ?>
				    	<div class="col-md-6">
				    		No reviews yet!
				    	</div>
				    <?php endif; ?>
					</div>
					<div class="row mb-3 collapse" id="collapse<?php echo e($wKey); ?>">
						<div class="offset-md-1 col-md-4">
							<div class="form-group row">
	                          <?php echo e(Form::label('description', 'Description', array('class' => 'col-md-4 control-label text-md-right'))); ?>

	                          <div class="col-md-8">
	                            <?php echo e(Form::textarea('description', Request::old('description'), array('class' => 'form-control', 'rows' => '3'))); ?>

	                          </div>
	                      </div>	                      
						</div>
						<div class="col-md-4">
							<div class="form-group row">
	                          <?php echo e(Form::label('img', 'Image', array('class' => 'col-md-4 control-label text-md-right'))); ?>

	                          <div class="col-md-8">
	                            <?php echo e(Form::file('img', array('class' => 'form-control'))); ?>

	                          </div>
	                      </div>	                      
						</div>
						<div class="col-md-3">
							<div class="form-group row">
	                          <div class="col-md-8">
	                            <?php echo e(Form::submit('Add to cart', array('class' => 'cart-btn mt-2 form-inline'))); ?>

	                          </div>
	                      </div>	                      
						</div>
						
					</div>
				<?php echo e(Form::close()); ?>

           		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	            <?php if(!count($workers)): ?>
		            <div class="col-md-12">
		            	No workers found!
		            </div>
	            <?php else: ?>
	            	<div class="col-md-12">
	            		<?php echo $workers->appends(\Request::except('page'))->render(); ?>

	            	</div>
	            <?php endif; ?>
		          	
			</div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>" defer></script>
<script type="text/javascript">
$(function(){    
	$('.cart-btn').click(function(){
		var desc = $(this).parent().parent().parent().parent().find('textarea[name="description"]');
		var img = $(this).parent().parent().parent().parent().find('input[name="img"]');
		var fileExtension = ['jpeg', 'jpg', 'png'];
		if(desc.val() == '') {
			alert('Please enter description of work')
			desc.focus()
			return false;
		} else if(img.val() == '') {
			/*alert('Please select an image')
			img.focus()
			return false;*/
		} else if ($.inArray(img.val().split('.').pop().toLowerCase(), fileExtension) == -1) {
            alert("Only formats are allowed : "+fileExtension.join(', '));
        	return false;        
		}
	})
	$('select[name="slotFrom"] option[value="<?php echo e(config('app.endH')); ?>"]').remove()
	$('select[name="slotFrom"]').click(function(){
		$('select[name="slotTo"] option').removeAttr('disabled')
		for (var i = <?php echo e(config('app.startH')); ?>; i <= $('select[name="slotFrom"]').val(); i++) {
			$('select[name="slotTo"] option[value="'+(i < 10 ? pad("0" + i, 2) : i)+'"]').attr('disabled', 'disabled')
		};
		$('select[name="slotTo"]').val(parseInt($('select[name="slotFrom"]').val()) < 9 ? pad("0" + (parseInt($('select[name="slotFrom"]').val()) + 1), 2) : parseInt($('select[name="slotFrom"]').val()) + 1).change()
	})
    $( "#bDate" ).datepicker({ 
                        dateFormat: 'dd-mm-yy',
                        minDate: 3
                     });
    $('form').on('submit', function(){
    	if($( "#bDate" ).val() == '') {
    		$( "#bDate" ).focus();
    		return false;
    	}

    	if($('select[name="subCat"]').val() == 0 || $('select[name="subCat"]').val() === null) {
    		$('select[name="subCat"]').addClass('is-invalid');
    		return false;	
    	}
    })

    $('select[name="cat"]').change(function(){
    	$('select[name="subCat"]').removeClass('is-invalid')
    	$.ajax({
	        url: "<?php echo e(url('/api/getSub')); ?>",
	        method: 'get',
	        data: {
	           api_token: '<?php echo e($token); ?>',
	           cat: $('select[name="cat"]').val()
	        },
	        success: function(result){
	           var vid = $('select[name="subCat"]');
	           vid.empty();
	           $.each(result, function(index, value) {
	            vid.append('<option value="' + index +'">' + value + '</option>');
	           });

	           if($.isEmptyObject(result)) {
	            vid.append('<option value="0">Select</option>');
	           }
	           $("#vid").trigger("change");
	      },
	      error: function(request, status, error) {}
	    });
    })

    function pad (str, max) {
	  str = str.toString();
	  return str.length < max ? pad("0" + str, max) : str;
	}
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>