<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Revenue from services</div>

                <div class="card-body">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?> 
                    <?php echo e(Form::open(['url' => '/commission', 'method' => 'get', 'style' => 'width:100%', 'class' => 'mt-3 ml-3'])); ?>

                      <fieldset class="search">
                          <div class="form-group row" style="line-height:35px">
                            <div class="col-md-3">
                              Year <?php echo Form::select('year', [0 => 'All', 2019 => '2019'], $year, ['class' => 'form-control m-bot15 float-right', 'id' => 'cat', 'style' => 'width:auto']); ?>

                            </div>
                            <div class="col-md-3 mr-2">
                              Month <?php echo Form::select('month', [0 => 'All', 1 => 'January', 
                                                                          2 => 'February', 
                                                                          3 => 'March',
                                                                          4 => 'April',
                                                                          5 => 'May',
                                                                          6 => 'June',
                                                                          7 => 'July',
                                                                          8 => 'August',
                                                                          9 => 'September',
                                                                          10 => 'October',
                                                                          11 => 'November',
                                                                          12 => 'December'
                                ], $month, ['class' => 'form-control m-bot15 float-right', 'id' => 'cat', 'style' => 'width:auto']); ?>                              
                            </div>
                          <?php echo e(Form::submit('Search', array('class' => 'btn btn-primary'))); ?>

                        </div>
                      </fieldset>
                    <?php echo e(Form::close()); ?>

                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          <th scope="col">Order #</th>
                          <th scope="col">Date</th>
                          <th scope="col">Amount</th>
                          <th scope="col">Commission</th>
                        </tr>
                      </thead>
                      <tbody>                        
                          <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td>
                                <a href="<?php echo e(URL::to('order-details/' . $order->id)); ?>">#<?php echo e(str_pad($order->id, 4, '0', STR_PAD_LEFT)); ?></a>
                              </td>
                              <td>
                                <?php echo e(date('d-m-Y', strtotime($order->created_at))); ?>

                              </td>
                              <td><?php echo e($order->amount); ?></td>
                              <td><?php echo e(number_format($order->commision, 2)); ?></td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php if(!count($orders)): ?>
                            <tr class="no-rec">
                              <td colspan="4">No records!</td>
                            </tr>
                          <?php endif; ?>
                          <tr>
                            <td colspan="3">Total</td>
                            <td><?php echo config('app.currency'); ?><?php echo e(number_format($total, 2)); ?></td>
                          </tr>
                        </tbody>
                    </table>
                  <?php echo $orders->appends(\Request::except('page'))->render(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>