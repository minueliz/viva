<?php $__env->startSection('title', '| Product'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<!-- if there are creation errors, they will show here -->
	<?php if($errors->any()): ?>
		<div class="alert alert-danger">
		  <?php echo e(Html::ul($errors->all())); ?>

		</div>
	<?php endif; ?>
	<?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="row justify-content-center single-prod">        
	   <div class="col-md-6">
	   	<?php if(!empty($product->img)): ?>
		  <img class="img-responsive" src="<?php echo e(URL::asset('images/products')); ?>/<?php echo e($product->img); ?>" >
		<?php else: ?>
		  <img class="img-responsive" src="<?php echo e(URL::asset('images/products')); ?>/214x150.png" >
		<?php endif; ?>
	   </div>
	   <div class="col-md-6">
	   	<div class="col-md-12">
		 <h1><?php echo e($product->name); ?></h1>
		</div>
		<div class="row">
		 <div class="col-md-12">
		  <!-- <p class="description">
		   Classic film camera. Uses 620 roll film.
		   Has a 2&frac14; x 3&frac14; inch image size.
		  </p> -->
		 </div>
		</div><!-- end row -->

		<div class="row">
		 <div class="col-md-4">
		  <!-- <span class="sr-only">Four out of Five Stars</span> -->
		  <?php for($i=1; $i<=$rating; $i++): ?>
		  	<span class="fas fa-star" aria-hidden="true"></span>
		  <!-- <span class="label label-success">61</span> -->
		  <?php endfor; ?>
		  <?php for($i=$rating; $i<5; $i++): ?>
		  	<span class="far fa-star" aria-hidden="true"></span>
		  <!-- <span class="label label-success">61</span> -->
		  <?php endfor; ?>
		 </div>
		</div><!-- end row -->

		<div class="row">
		 <div class="col-md-12 bottom-rule">
		  <h2 class="product-price"><?php echo config('app.currency'); ?><?php echo e(number_format($product->amount, 2)); ?></h2>
		 </div>
		</div><!-- end row -->
		<?php if($product->qty): ?>
			<?php echo e(Form::open(array('url' => 'cart/' . $product->id, 'class' => 'pull-right'))); ?>

				<div class="row add-to-cart">
				 <div class="col-md-5 product-qty">
				  <?php echo e(Form::number('qty'.$product->id, 1, array('class' => 'btn btn-default btn-lg btn-qty', 'min' => 1, 'max' => 999))); ?>

		          <?php echo e(Form::hidden('_method', 'POST')); ?>

				 </div>
				 <div class="col-md-4">
				  <?php echo e(Form::submit('Add to Cart', array('class' => 'btn btn-lg btn-brand btn-full-width'))); ?>

				 </div>
				</div><!-- end row -->
			<?php echo e(Form::close()); ?>


			<div class="row">
			 <div class="col-md-5 text-center">
			  <span>In Stock</span>
			 </div>
			</div><!-- end row -->
		<?php else: ?>
			<div class="row">
			 <div class="col-md-5">
			<span class="out-of-stock">Out of stock</span>
			 </div>
			</div><!-- end row -->
		<?php endif; ?>
		<div class="row">
		 <div class="col-md-12 bottom-rule mt-2"></div>
		</div><!-- end row -->

		<!-- Nav tabs -->
		<ul class="nav nav-tabs">
		  <li class="nav-item">
		    <a class="nav-link" href="#description" data-toggle="tab" role="tab" aria-controls="description" aria-selected="true">Description</a>
		  </li>
		  <li class="nav-item">
		    <a class="nav-link" href="#reviews" data-toggle="tab" role="tab" aria-controls="reviews" aria-selected="false">Reviews</a>
		  </li>
		</ul>
		<!-- Tab panes -->
		<div class="tab-content">
		 <div role="tabpanel" class="tab-pane fade show" id="description">
		 	<p class="mt-2">
				<?php echo e($product->description); ?>  
			</p>
		 </div>
		 <div role="tabpanel" class="tab-pane mt-2 fade" id="reviews">
		 	<?php if(count($reviews)): ?>
		 		<?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  	<div class="row <?php echo e((($key+1) < count($reviews)) ? 'border-bottom' : ''); ?> mb-2">
		        	    <div class="col-md-2">
		        	        <?php if(!empty($review->user->userinformation->img)): ?>
		                        <div class="inset">
		                          <img src="<?php echo e(URL::asset('images/profile')); ?>/<?php echo e($review->user->userinformation->img); ?>">
		                        </div>
		                    <?php else: ?>
		        	        	<img src="<?php echo e(URL::asset('images/profile')); ?>/" class="img img-rounded img-fluid"/>
		                    <?php endif; ?>
		        	        <!-- <p class="text-secondary text-center">15 Minutes Ago</p> -->
		        	    </div>
		        	    <div class="col-md-10">
		        	        <p>
		        	            <a class="float-left namel" href="#"><strong><?php echo e(ucfirst($review->user->name)); ?></strong></a>
		        	            <?php for($i=$rating; $i<5; $i++): ?>
									<span class="float-right"><span class="text-warning far fa-star" aria-hidden="true"></span></span>
								<?php endfor; ?>
		        	            <?php for($i=1; $i<=$rating; $i++): ?>
							  		<span class="float-right"><i class="text-warning fa fa-star"></i></span>
								<?php endfor; ?>
		        	       </p>
		        	       <div class="clearfix"></div>
		        	        <p><?php echo e($review->comment); ?></p>
		        	    </div>
			        </div>
			    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    <?php else: ?>
		    	<div class="row">
		    		No reviews yet!
		    	</div>
		    <?php endif; ?>
		  	<?php echo $reviews->appends(['tab' => 'review'])->render(); ?>

		 </div>
		</div>
	   </div>
	</div>
	<?php if(count($relatedProducts)): ?>
	<div class="row mt-5">
        <div class="col-md-12">
          <h3>Related Products</h3>
          <div class="owl-carousel products carousel mt-3 mb-4">
              <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                  <a href="<?php echo e(URL::to('product/' .  Str::slug($product->name) . '/' . $product->id)); ?>">
                      <?php if(!empty($product->img)): ?>
                          <img src="<?php echo e(URL::asset('images/products')); ?>/<?php echo e($product->img); ?>" >
                      <?php else: ?>
                          <img src="<?php echo e(URL::asset('images/products')); ?>/214x150.png" >
                      <?php endif; ?>
                  </a>
                  <div class="cat-name"><?php echo e($product->name); ?></div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div> 
<?php $__env->stopSection(); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/owl.carousel.js')); ?>"></script>
<script type="text/javascript">
	$( document ).ready(function() {
		$('.carousel').owlCarousel({
              loop:true,
              margin:10,
              nav:false,
              autoplay: true,
              autoHeight:true,
              responsive:{
                  0:{
                      items:2
                  },
                  600:{
                      items:3
                  },
                  1000:{
                      items:5
                  }
              }
        })

		if(window.location.href.indexOf('tab=review') > -1) {
			$('a[aria-controls="reviews"]').trigger('click')
		} else 
			$('a[aria-controls="description"]').trigger('click')
	})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>