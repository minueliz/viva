<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
        <link href="<?php echo e(asset('css/fontawesome-all.min.css')); ?>" rel="stylesheet">

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        
    </head>
    <body>
        <div id="app">
            <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <main class="home py-4">
              
              <!--START CAROUSEL-->
              <div id="carouselExampleIndicators" class="carousel slide home-slider mb-5" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                  <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                  <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                  <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>
                <!-- Wrapper for slides -->
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img class="d-block w-100" src="<?php echo e(URL::asset('images/3.jpg')); ?>" data-color="lightblue" alt="First Image">
                    <div class="carousel-caption d-md-block">
                      <h5>We Are The Best Home Service For Making Your Home Shine</h5>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(URL::asset('images/2.jpg')); ?>" data-color="firebrick" alt="Second Image">
                    <div class="carousel-caption d-md-block">
                      <h5>Making your Home Shine and Spotless Is Our Business And Priority</h5>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(URL::asset('images/1.jpg')); ?>" data-color="violet" alt="Third Image">
                    <div class="carousel-caption d-md-block">
                      <h5>Our Home Service Providers will Make You Proud in Society</h5>
                    </div>
                  </div>
                </div>
                <!-- Controls -->
                <!-- <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
                </a>
                  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
                </a> -->
              </div>
              <!--END CAROUSEL-->              

              <div class="container">
                  
                  <div class="row">
                  <!-- //banner-slider -->
                  <div class="col-md-12">
                    <h3>Services</h3>
                    <div class="owl-carousel service-categories carousel-com mt-3 mb-4">
                        <?php $__currentLoopData = $serviceCats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="item">
                            <?php if(!empty($cat->img)): ?>
                                <img src="<?php echo e(URL::asset('images/service-categories')); ?>/<?php echo e($cat->img); ?>" >
                            <?php else: ?>
                                <img src="<?php echo e(URL::asset('images/service-categories')); ?>/214x150.png" >
                            <?php endif; ?>
                            <div class="cat-name"><?php echo e($cat->category); ?></div>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-12">
                      <h3>Products</h3>
                      <div class="owl-carousel products carousel-com mt-3 mb-4">
                          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                              <a href="<?php echo e(URL::to('product/' .  Str::slug($product->name) . '/' . $product->id)); ?>">
                                  <?php if(!empty($product->img)): ?>
                                      <img src="<?php echo e(URL::asset('images/products')); ?>/<?php echo e($product->img); ?>" >
                                  <?php else: ?>
                                      <img src="<?php echo e(URL::asset('images/products')); ?>/214x150.png" >
                                  <?php endif; ?>
                              </a>
                              <div class="cat-name"><?php echo e($product->name); ?></div>
                            </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                  </div>
              </div>
          </main>
          <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </body>
    
    <script src="<?php echo e(asset('js/owl.carousel.js')); ?>"></script>
    <script>
    $(function(){
        $( document ).ready(function() {
          $('.carousel').carousel({
            interval: 6000,
            pause: "false",
            ride: true
          });

          $('.carousel-com').owlCarousel({
              loop:true,
              margin:10,
              nav:false,
              autoplay: true,
              autoHeight:true,
              responsive:{
                  0:{
                      items:2
                  },
                  600:{
                      items:3
                  },
                  1000:{
                      items:5
                  }
              }
          })          
          
        });
    });
    </script>
</html>