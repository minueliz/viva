<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UserInfoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_informations', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('user_id')->unique();
            $table->string('fname');
            $table->string('lname');
            $table->string('street');
            $table->Integer('district_id')->nullable();
            $table->string('pin_code');
            $table->string('phone');
            $table->string('alt_phone')->nullable();
            $table->Integer('sec_q')->nullable();
            $table->string('sec_a');
            $table->string('img')->nullable();
            $table->string('exp_proof')->nullable();
            $table->string('addr_proof')->nullable();
            $table->timestamps();

            $table->foreign('user_id')->references('id')->on('users');
            $table->foreign('sec_q')->references('id')->on('sec_questions');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_informations');
    }
}
