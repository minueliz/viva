<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class ServiceOrdered extends Mailable
{
    use Queueable, SerializesModels;

    protected $user;
    protected $itemDetails;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(\App\User $user, $itemDetails)
    {
        $this->user = $user;
        $this->itemDetails = $itemDetails;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->markdown('emails.service-ordered')
                    ->subject('Your service has been booked for ' . $this->itemDetails['bDate'])
                    ->with([
                            'name' => $this->user->name,
                            'details' => $this->itemDetails
                        ]);
    }
}
