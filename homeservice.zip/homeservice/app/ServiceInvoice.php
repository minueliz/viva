<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ServiceInvoice extends Model
{
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id', 'item_id', 'hours', 'additional_purchases', 'additional_amount', 'total'
    ];

    public $table = "service_invoices";

    public function service()
    {
        return $this->belongsTo('App\OrderItem', 'item_id', 'id');
    }
}