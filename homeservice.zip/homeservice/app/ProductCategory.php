<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductCategory extends Model
{
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id', 'category', 'status'
    ];

    protected $primaryKey = 'id';

    public $table = "product_categories";

    protected $attributes = [
        'status' => 1,
    ];

    public function products()
    {
        return $this->hasMany('App\Product');
    }
}