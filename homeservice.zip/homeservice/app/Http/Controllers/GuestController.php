<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use Auth;
use Validator;
use Cart;
use Session;
use CartExtended;
use App\Mail\ServiceOrdered;
use Illuminate\Support\Facades\Mail;
use Carbon\Carbon;
use DateInterval;
use App\Mail\ServiceRejected;

class GuestController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware(['guest']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $serviceCats = \App\ServiceCategory::where('status', 1)->paginate(config('app.per_page'));

        $products = \App\Product::where('status', 1)->paginate(config('app.per_page'));
        return view('welcome', ['serviceCats' => $serviceCats, 'products' => $products]);
    }

    public function singleProduct($productName, $productId) {
        $product = \App\Product::where('status', 1)
                                 ->where('id', $productId)
                                 ->firstOrFail();

        $relatedProducts = \App\Product::where('status', 1)
                                        ->where('product_category', $product->product_category)
                                        ->take(10)
                                        ->get();

        $reviews = $product->reviews()->where('status', 1)->paginate(5);

        $rating = \App\Review::where('status', 1)
                                ->where('product_id', $product->id)
                                ->avg('rating');
        
        return view('single-product', ['product' => $product, 
                                        'relatedProducts' => $relatedProducts,
                                        'reviews' => $reviews,
                                        'rating' => $rating]);
    }

    public function products(Request $request) {
        $products = \App\Product::where('status', 1);

        if(!is_null($request->input('keyword')) && !is_null($request->input('cat'))) {
            $products = $products
                                    ->where('name', 'LIKE', '%'. $request->input('keyword') .'%')
                                    ->orWhere('description', 'LIKE', '%'. $request->input('keyword') .'%')
                                    ->where('product_category', $request->input('cat'))
                                    ->paginate(config('app.per_page_lists'));
        } elseif(!is_null($request->input('cat'))) {
            $products = $products
                                    ->where('product_category', $request->input('cat'))
                                    ->paginate(config('app.per_page_lists'));
        } elseif(!is_null($request->input('keyword'))) {
            $products = $products
                                    ->where('name', 'LIKE', '%'. $request->input('keyword') .'%')
                                    ->orWhere('description', 'LIKE', '%'. $request->input('keyword') .'%')
                                    ->paginate(config('app.per_page_lists'));
                                    //->toSql();
        } else {
            $products = \App\Product::where('status', 1)->paginate(config('app.per_page_lists'));
        }
        $prodCats = \App\ProductCategory::where('status', 1)->pluck('category', 'id');

        return view('shop', ['products' => $products, 'prodCats' => $prodCats, 'keyword' => $request->input('keyword'), 'cat' => $request->input('cat')]);
    }

    public function services(Request $request) {
        $serviceCats = \App\ServiceCategory::whereNull('parent_id')
                                            ->where('status', 1)
                                                    ->pluck('category', 'id');
        $serviceSlots = \App\ServiceSlot::where('status', 1)
                                                    ->pluck('slot', 'id');

        //foreach($serviceSlots as $slotId => $slot) break;
        //foreach($serviceSlots as $subCatId => $subCat) break;

        if(!is_null($request->input('bDate'))) {
            $bDate = join('-', array_reverse( explode('-', $request->bDate)));
            $_slotFrom = $request->slotFrom;
            $_slotTo = $request->slotTo;
            $slotFrom = $bDate . ' ' . $request->slotFrom . ':00';
            $slotTo = $bDate . ' ' . $request->slotTo . ':00';
            $catId = $request->cat;
            $subCat = $request->subCat;

            $subCats = \App\ServiceCategory::where('parent_id', $catId)
                                            ->where('status', 1)
                                            ->pluck('category', 'id');

            $workers = \App\User::select('users.*')
                                    ->where('worker_approved', 1)
                                    ->where('users.status', 1)
                                    ->leftJoin('order_items', function($join) use($slotFrom, $slotTo, $bDate)
                                         {
                                           $join->on('order_items.item_id', '=', 'users.id');
                                           $join->where('order_items.item_type', 2);
                                           //$join->whereBetween('order_items.service_slot_from', [$slotFrom, $slotTo]);
                                           //$join->whereBetween('order_items.service_slot_to', [$slotFrom, $slotTo]);
                                           $join->WhereRaw('(
                        (order_items.service_slot_from >= ? and order_items.service_slot_from < ?) or 
                        (order_items.service_slot_to > ? and  order_items.service_slot_to <= ?))', [$slotFrom, $slotTo, $slotFrom, $slotTo]);
                                           //$join->where('order_items.service_date', $bDate);
                                           $join->whereIn('order_items.status', [7, 1]);
                                         })
                                    ->leftJoin('leaves', function($join) use($bDate)
                                         {
                                           $join->on('leaves.user_id', '=', 'users.id');
                                           $join->where('leaves.status', 2);
                                           $join->whereRaw('? between leaves.from and leaves.to', [$bDate]);
                                         })
                                    ->rightJoin('user_informations', function($join) use($catId)
                                         {
                                           $join->on('user_informations.user_id', '=', 'users.id');
                                           $join->where('user_informations.service_category', $catId);
                                           if(Auth::user())
                                            $join->where('user_informations.district_id', Auth::User()->userinformation->district_id);
                                         })
                                    ->whereNull('order_items.id')
                                    ->whereNull('leaves.id')
                                    //->toSql();dd($workers);die;
                                    ->paginate(config('app.per_page_lists'));
        } else {
            $bDate = date('Y-m-d', strtotime('+3 day'));
            $_slotFrom = 8;
            $_slotTo = 10;
            $slotFrom = $bDate . '08:00';
            $slotTo = $bDate . '10:00';
            foreach($serviceCats as $catId => $cat) {
                $subCats = \App\ServiceCategory::where('parent_id', $catId)
                                                ->where('status', 1)
                                                ->pluck('category', 'id');
                break;
            }
            foreach($subCats as $subCat => $value) break;
//var_dump($bDate, $slotId, $catId);die;
            $workers = \App\User::select('users.*')
                                    ->where('worker_approved', 1)
                                    ->where('users.status', 1)
                                    ->leftJoin('order_items', function($join) use($slotFrom, $slotTo, $bDate)
                                         {
                                           $join->on('order_items.item_id', '=', 'users.id');
                                           $join->where('order_items.item_type', 2);
                                           $join->WhereRaw('(
                            (order_items.service_slot_from > ? and order_items.service_slot_from < ?) or 
                            (order_items.service_slot_to > ? and  order_items.service_slot_to < ?))', [$slotFrom, $slotTo, $slotFrom, $slotTo]);
                                           $join->whereIn('order_items.status', [7, 1]);
                                         })
                                                                            ->leftJoin('leaves', function($join) use($bDate)
                                         {
                                           $join->on('leaves.user_id', '=', 'users.id');
                                           $join->where('leaves.status', 2);
                                           $join->whereRaw('? between leaves.from and leaves.to', [$bDate]);
                                         })
                                                                            
                                    ->rightJoin('user_informations', function($join) use($catId)
                                         {
                                           $join->on('user_informations.user_id', '=', 'users.id');
                                           $join->where('user_informations.service_category', $catId);
                                           if(Auth::user())
                                            $join->where('user_informations.district_id', Auth::User()->userinformation->district_id);
                                         })
                                    ->whereNull('order_items.id')
                                    ->whereNull('leaves.id')
                                    //->toSql();dd($workers);die;
                                    ->paginate(config('app.per_page_lists'));
        }

        for ($i=config('app.startH'); $i <= config('app.endH'); $i++) { 
            $hours[] = ['key' => sprintf('%02d', $i), 'value' => sprintf('%02d', $i)];
        }
        $hours = collect($hours);
        $hours = $hours->pluck('key', 'value');

        return view('services', ['workers' => $workers, 'serviceCats' => $serviceCats, 'subCats' => $subCats, 'serviceSlots' => $serviceSlots, 'cat' => $catId, 'subCat' => $subCat, 'bDate' => join('-', array_reverse( explode('-', $bDate))), '_slotFrom' => $_slotFrom, '_slotTo' => $_slotTo, 'token' => ((Auth::user())?Auth::user()->api_token:''), 'hours' => $hours]);
    }

    public function about() {
        return view('about');
    }

    public function contact() {
        return view('contact');
    }

    public function showCart() {
        $this->saveCart();
        $cartCon = Cart::content();
        $cardTypes = \App\Credit::distinct()->pluck('type', 'type');

        $totalExceptServ = 0;        
        foreach ($cartCon as $key => $item) { 
            if(get_class($item->model) == 'App\Product') { $totalExceptServ += ($item->qty * $item->price); }
        }

        return view('cart', ['cartCon' => $cartCon, 'total' => Cart::total(2, '.', ''), 'payable' => $totalExceptServ, 'cardTypes' => $cardTypes, 'hasProd' => false, 'hasServ' => false]);
    }

    public function addToCart($id, Request  $request) {
        $cartCon = Cart::content();

        if($request->_type == 'service') {            
            $worker = \App\User::findOrFail($id);

            if(Auth::check()) {
                $pendingPayment = \App\OrderItem::where('status', 11)->get();
                foreach ($pendingPayment as $key => $value) {
                    if($value->order->user_id == Auth::user()->id)
                        return redirect()->back()->withErrors(['id'.$worker->id => 'You have pending payment, for previous service booking.']);   
                }
            }            

            $cat = \App\ServiceCategory::findOrFail($request->_cat);
            $subCat = \App\ServiceCategory::findOrFail($request->_subCat);
            $bDate = join('-', array_reverse( explode('-', $request->_bDate)));
            
            $slotFrom = $bDate . ' ' . $request->_slotFrom . ':00';
            $slotTo = $bDate . ' ' . $request->_slotTo . ':00';
            
            $ifInCart = $cartCon->search(function ($cartItem, $rowId) use ($worker, $request, $bDate) {
                            return (($cartItem->id == $worker->id) 
                                && ($cartItem->options->cat == $request->_cat) 
                                && ($cartItem->options->bDate == $bDate) 
                                && (strtotime($cartItem->options->slotFrom) >= strtotime($request->_slotFrom) || strtotime($cartItem->options->slotFrom) <= strtotime($request->_slotTo))
                                && (strtotime($cartItem->options->slotTo) >= strtotime($request->_slotFrom) || strtotime($cartItem->options->slotTo) <= strtotime($request->_slotTo)));
                        });
            if($ifInCart)
                return redirect()->back()->withErrors(['id'.$worker->id => 'Service already added to cart.']);

            $ifInCartS = $cartCon->search(function ($cartItem, $rowId) use ($worker, $request, $bDate) {
                            return (($cartItem->options->cat == $request->_cat) 
                                && ($cartItem->options->bDate == $bDate) 
                                && (strtotime($cartItem->options->slotFrom) >= strtotime($request->_slotFrom) || strtotime($cartItem->options->slotFrom) <= strtotime($request->_slotTo))
                                && (strtotime($cartItem->options->slotTo) >= strtotime($request->_slotFrom) || strtotime($cartItem->options->slotTo) <= strtotime($request->_slotTo)));
                        });
            if($ifInCartS)
                return redirect()->back()->withErrors(['id'.$worker->id => 'Service from another employee is already in the cart.']);

            $imageName = null;
            if(isset($request->img)) {
                $imageName = 'p' . time() . '.' . $request->img->getClientOriginalExtension();

                $request->img->move(
                    base_path() . '/public/images/serv/', $imageName
                );
            }

            $servTitle = $worker->name . ' (' . $cat->category . '-' . $subCat->category . ') <br/>' . $request->_bDate . '<br/>' . $request->_slotFrom .':00 - '.$request->_slotTo.':00' . '<br/>Per hour amount: '.config('app.currency').$worker->userinformation->per_hour_amount;
            Cart::add($worker->id, $servTitle, round((strtotime($slotTo) - strtotime($slotFrom))/3600, 1), $worker->userinformation->per_hour_amount, [
                    'cat' => $cat->id,
                    'subCat' => $subCat->id,
                    'bDate' => $bDate,
                    'slotFrom' => $slotFrom,
                    'slotTo' => $slotTo,
                    'description' => $request->description,
                    'img' => $imageName,
                    'catName' => $cat->category,
                    'subCatName' => $subCat->category,
                    'slotName' => $request->_slotFrom .' :00 - '.$request->_slotTo.' :00',
                    'per' => $worker->userinformation->per_hour_amount
                    ])->associate('\App\User');

            $this->saveCart();
            
            return redirect()->back()->with("success".$worker->id, "Service added to cart.");
        } else {
            $product = \App\Product::findOrFail($id);

            $ifInCart = $cartCon->search(function ($cartItem, $rowId) use ($product) {
                            return $cartItem->id === $product->id;
                        });
            $inCartQty = 0;
            if($ifInCart) {
                $cartElem = Cart::get($ifInCart);
                $inCartQty = $cartElem->qty;
            }

            if($product->qty < ($request->{'qty'.$product->id} + $inCartQty))
                return redirect()->back()->withErrors(['qty'.$product->id => 'Sorry! The required quantity is not available.']);

            Cart::add($product->id, $product->name, $request->{'qty'.$product->id}, $product->amount)->associate('\App\Product');
            $cartCon = Cart::content();
            
            $this->saveCart();

            $cardTypes = \App\Credit::distinct()->pluck('type', 'type');

            if(strpos($request->headers->get('referer'), 'product') !== false) { 
                return redirect()->back()->with("success", "Product added to cart.");
            } else {
                return redirect()->back()->with("success".$product->id, "Product added to cart.");
            }
        }
        
    }

    public function updateQty(Request  $request) {
        $rowId = $request['rowId'];
        $lineItem = Cart::get($rowId);
        $product = \App\Product::findOrFail($lineItem->id);

        $fields = array(
                    'qty'.$product->id => ['required', 'numeric', 'between:1, 999']
                    );

        $validator = Validator::make($request->all(), $fields, [], ['qty'.$product->id => 'Quantity']);
        if ($validator->fails()) 
            return redirect('cart')
                        ->withErrors($validator)
                        ->withInput();
        
        $qty = $request['qty'.$product->id];

        if($product->qty < $qty)
            return redirect('cart')->withErrors(['qty'.$product->id => 'Sorry! The requested quantity of this product is not available.']);

        Cart::update($rowId, ['qty' => $qty]);

        $this->saveCart();

        $cardTypes = \App\Credit::distinct()->pluck('type', 'type');
        $cartCon = Cart::content();

        $totalExceptServ = 0;        
        foreach ($cartCon as $key => $item) { 
            if(get_class($item->model) == 'App\Product') { $totalExceptServ += ($item->qty * $item->price); }
        }

        return redirect('cart')->with(['cartCon' => $cartCon, 'total' => Cart::total(2, '.', ''), 'payable' => $totalExceptServ, 'cardTypes' => $cardTypes]);
    }

    public function removeCartItem(Request  $request) {
        $rowId = $request['rowId'];

        try {
            Cart::remove($rowId);
        } catch(Exception $e) {}

        $this->saveCart();

        $cartCon = Cart::content();
        $cardTypes = \App\Credit::distinct()->pluck('type', 'type');

        $totalExceptServ = 0;        
        foreach ($cartCon as $key => $item) { 
            if(get_class($item->model) == 'App\Product') { $totalExceptServ += ($item->qty * $item->price); }
        }

        return redirect('cart')->with(['cartCon' => $cartCon, 'total' => Cart::total(2, '.', ''), 'payable' => $totalExceptServ, 'cardTypes' => $cardTypes]);
    }

    public function checkout(Request $request) {
        if($request->exists('shipping_addr'))
            $fields['shipping_addr'] = 'required|string';
        if($request->exists('service_addr'))
            $fields['service_addr'] = 'required|string';

        if($request->_onlyS != '1') 
            $fields = [
                    'cardName' => ['required', 'string', 'max:191', 'alpha_spaces'],
                    'cardNumber' => 'required|numeric|between:1000000000000000,9999999999999999',
                    'expiry' => 'required|card_expiry',
                    'cvv' => 'required|numeric|between:100,999'];

        $cartCon = Cart::content();
        $totalExceptServ = 0;        
        foreach ($cartCon as $key => $item) { 
            if(get_class($item->model) == 'App\Product') { $totalExceptServ += ($item->qty * $item->price); }
        }

        $pendingPayment = \App\OrderItem::where('status', 11)->get();
        foreach ($pendingPayment as $key => $value) {
            if($value->order->user_id == Auth::user()->id)
                return redirect()->back()->withErrors(['error' => 'You have pending payment, for previous service booking.']);   
        }

        $validator = Validator::make($request->all(), $fields, [], $this->attributes());

        if ($validator->fails()) 
            return redirect('cart')
                                    ->withErrors($validator)
                                    ->withInput();

        if($request->_onlyS != '1') {
            $balance = \App\Credit::where('user_id', Auth::user()->id)
                                    //->where('name_on_card', $request->cardName)
                                    ->where('card_no', $request->cardNumber)
                                    //->where('expiry', $request->expiry)
                                    //->where('cvv', $request->cvv)
                                    //->where('type', $request->cardType)
                                    ->first();
            if(!is_null($balance)) {
                if($balance->name_on_card != $request->cardName || $balance->expiry != $request->expiry || $balance->cvv != $request->cvv || $balance->type != $request->cardType)
                    return redirect()->back()->withErrors(['msg' => 'Card details were not found, please enter valid card details.'])->withInput();
                elseif($balance->balance < $totalExceptServ)
                    return redirect()->back()->withErrors(['msg' => 'Sorry! Your account does not have the necessary balance. Available amount, '.config('app.currency').$balance->balance])->withInput();
            } else {
                $balance = new \App\Credit;
                $balance->user_id = Auth::user()->id;
                $balance->card_no = $request->cardNumber;
                $balance->expiry = $request->expiry;
                $balance->cvv = $request->cvv;
                $balance->name_on_card = $request->cardName;
                $balance->type = $request->cardType;
                $balance->balance = 10000;
                $balance->save();
            }
        }

        //Re-check check inventory
        foreach ($cartCon as $key => $item) { 
            if(get_class($item->model) == 'App\Product') {
                $product = \App\Product::findOrFail($item->id);

                if($product->qty < $item->qty)
                    return redirect()->back()->withErrors(['qty'.$item->id => 'Sorry! The required quantity is not available.'])->withInput();
            } else {
                $servBooked = \App\OrderItem::where('item_id', $item->id)
                                                //->where('service_date', $item->options->bDate)
                                                ->whereBetween('order_items.service_slot_from', [$item->options->slotFrom, $item->options->slotTo])
                                                ->whereBetween('order_items.service_slot_to', [$item->options->slotFrom, $item->options->slotTo])
                                                //->where('service_slot', $item->options->slot)
                                                ->where('status', 1)
                                                ->get();
                if($servBooked->count()) {
                    return redirect()->back()
                                            ->withErrors(['msg'.$key => 'The service slot is not available.'])
                                            ->with(['serv' => 1])
                                            ->withInput();
                }
            }
        }

        if($request->_onlyS != '1') {
            $balance->balance -= $totalExceptServ;
            $balance->save();
            //Credit admin
            $admin = \App\Setting::find('3');
            $adminBalance = \App\Credit::where('user_id', $admin->value)->first();
            $adminBalance->balance += $totalExceptServ;
            $adminBalance->save();
        }

        $order = new \App\Order;
        $order->user_id = Auth::user()->id;
        $order->amount = $totalExceptServ;
        $order->shipping_address = $request->shipping_addr;
        $order->service_addr = $request->service_addr;
        $order->status = 1;
        $order->save();        

        foreach ($cartCon as $key => $item) { 
            if(get_class($item->model) == 'App\Product') {
                //Product
                $orderItem = new \App\OrderItem;
                $orderItem->order_id = $order->id;
                $orderItem->item_id = $item->id;
                $orderItem->item_type = 1;
                $orderItem->qty = $item->qty;
                $orderItem->amount = $item->price;
                $orderItem->status = 1;

                $orderItem->save();

                $product = \App\Product::findOrFail($item->id);
                $product->qty -= $item->qty;
                $product->save();
            } else {
                //Service
                $worker = \App\User::findOrFail($item->id);
                $orderItem = new \App\OrderItem;
                $orderItem->order_id = $order->id;
                $orderItem->item_id = $item->id;
                $orderItem->item_type = 2;
                $orderItem->qty = round((strtotime($item->options->slotTo) - strtotime($item->options->slotFrom))/3600, 1);
                
                $orderItem->amount = $orderItem->qty * $worker->userinformation->per_hour_amount;

                $commision = \App\Setting::find('2');
                $orderItem->commision = ($commision->value * $orderItem->qty * $worker->userinformation->per_hour_amount) / 100;

                $orderItem->service_subCat = $item->options->subCat;
                //$orderItem->service_date = $item->options->bDate;
                $orderItem->service_slot_from = $item->options->slotFrom;
                $orderItem->service_slot_to = $item->options->slotTo;
                $orderItem->description = $item->options->description;
                $orderItem->img = $item->options->img;
                $orderItem->status = 0;

                $orderItem->save();

                $user = \App\User::find($item->id);
                Mail::to($user)->send(new ServiceOrdered($user, [
                        'item_id' => $orderItem->id,
                        'bDate' => $item->options->bDate,
                        'catName' => $item->options->catName,
                        'subCatName' => $item->options->subCatName,
                        'slotName' => $item->options->slotName,
                        'custName' => Auth::user()->name,
                        'desc' => $item->options->description,
                        'img' => $item->options->img,
                    ]));
            }
        }

        CartExtended::clearCartDb(Auth::user()->id);
        Cart::destroy();
        $request->session()->put('orderId', $order->id);
        return redirect('order-details/' . $order->id);
    }

    private function saveCart() {
        if(Auth::check()) {
            try {
                Cart::store(Auth::user()->id);
            } catch(\Gloudemans\Shoppingcart\Exceptions\CartAlreadyStoredException $e) {
                CartExtended::updateCartDb(Auth::user()->id);
            }
        }/* else {
            try {
                Cart::store(Session::getId());
            } catch(\Gloudemans\Shoppingcart\Exceptions\CartAlreadyStoredException $e) {
                CartExtended::updateCartDb(Session::getId());
            }
        }*/
    }

    public function cron() {
        $items = \App\OrderItem::where('status', 0)->get();
        foreach ($items as $key => $value) {
            if($value->created_at->add(new DateInterval('P1D')) <= Carbon::now()) {
                $value->status = 6;
                $value->save();
                
                $user = \App\User::find($value->order->user_id);
                Mail::to($user)->send(new ServiceRejected($user, $value));
            }
        }
    }

    public function attributes()
    {
        return [            
            'qty' => 'Quantity',
            'cardName' => 'Name on Card',
            'cardNumber' => 'Card Number',
            'expiry' => 'Expiry Date',
            'cvv' => 'CVV Code',
            'shipping_addr' => 'Shipping Address',
            'service_addr' => 'Service Address'
        ];
    }
}
