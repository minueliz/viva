<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use Auth;
use Validator;
use Session;

class ServiceCategoryController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth', 'role:admin']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {   
        $service_categories = \App\ServiceCategory::whereNull('parent_id')
                                                    ->orderBy('status', 'desc')
                                                    ->paginate(config('app.per_page'));
        return view('service_categories.index', ['service_categories' => $service_categories]);
    }

    public function subcategories(Request $request, $stat=0) {
        $serviceCats = \App\ServiceCategory::whereNull('parent_id')
                                                    ->where('status', 1)
                                                    ->pluck('category', 'id');
        //var_dump($pcategory);die;
        if(!is_null($request->input('pcategory'))) 
                $subCats = \App\ServiceCategory::where('parent_id', $request->input('pcategory'))
                                                        ->paginate(config('app.per_page'));
            else
                foreach($serviceCats as $key => $cat) {
                    $subCats = \App\ServiceCategory::where('parent_id', $key)
                                                    ->paginate(config('app.per_page'));
                    break;
                }

        if($stat) {
            Session::flash('success', 'Service subcategory saved successfully !'); 
            return view('service_categories.subcategories', ['serviceCats' => $serviceCats, 'subCats' => $subCats, 'pcategory' => $request->input('pcategory')]);
        } else
            return view('service_categories.subcategories', ['serviceCats' => $serviceCats, 'subCats' => $subCats, 'pcategory' => $request->input('pcategory')]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id) {
        // get the vehicle
        $service_category = \App\ServiceCategory::findOrFail($id);
        return view('service_categories.show', ['service_category' => $service_category]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create($slug=null)
    {
        $categories = \App\ServiceCategory::whereNull('parent_id')
                                                    ->where('status', 1)
                                                    ->orderBy('status', 'desc')
                                                    ->pluck('category', 'id');
        return view('service_categories.create', ['slug' => $slug, 'categories' => $categories]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store(Request $request)
    {        
        $fields = array('category' => 'required|alpha_spaces');
        if(isset($request['image']) && !is_null($request['image'])) {
            $fields['image'] = 'mimes:jpg,jpeg,png';
        }
        
        $validator = Validator::make($request->all(), $fields, [], $this->attributes());

        if($request->subcat) 
            if ($validator->fails()) 
                return redirect('service-categories/create/sub')
                        ->withErrors($validator)
                        ->withInput();
        else
            if ($validator->fails()) 
                return redirect('service-categories/create')
                        ->withErrors($validator)
                        ->withInput();
        
        $service_category = new \App\ServiceCategory;
        $service_category->category = $request->category;

        if($request->subcat) {
            $service_category->parent_id = $request->pcategory;
        }

        $imageName = '';
        if(isset($request['image'])) {
            $imageName = 'p' . time() . '.' . $request['image']->getClientOriginalExtension();

            $request['image']->move(
                base_path() . '/public/images/service-categories/', $imageName
            );
        }
        $service_category->img = $imageName;

        $service_category->save();

        if($request->subcat)
            return $this->subcategories($request, 1);
        else
            return redirect('service-categories/')->with("success","Service category saved successfully !");
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id, $slug=null)
    {
        $service_category = \App\ServiceCategory::findOrFail($id);
        $categories = \App\ServiceCategory::whereNull('parent_id')
                                                    ->orderBy('status', 'desc')
                                                    ->pluck('category', 'id');
        
        return view('service_categories.edit', ['service_category' => $service_category, 'slug' => $slug, 'categories' => $categories]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update($id, Request $request)
    {
        $fields = array('category' => 'required|alpha_spaces');
        if(isset($request['image']) && !is_null($request['image'])) {
            $fields['image'] = 'mimes:jpg,jpeg,png';
        }

        $validator = Validator::make($request->all(), $fields, [], $this->attributes());

        if($request->subcat) { 
            if ($validator->fails()) 
                return redirect('service-categories/'.$id.'/edit/sub')
                        ->withErrors($validator)
                        ->withInput();
        } else {
            if ($validator->fails()) 
                return redirect('service-categories/'.$id.'/edit')
                        ->withErrors($validator)
                        ->withInput();
        }


        $service_category = \App\ServiceCategory::find($id);
        $service_category->category = $request->category;

        if($request->subcat) {
            $service_category->parent_id = $request->pcategory;
        }

        $imageName = ''; 
        if(!is_null($request['image'])) {
            $imageName = 'p' . time() . '.' . $request['image']->getClientOriginalExtension();

            $request['image']->move(
                base_path() . '/public/images/service-categories/', $imageName
            );
            $service_category->img = $imageName;
        }        
        
        $service_category->save();
        if($request->subcat) 
            return $this->subcategories($request, 1);
        else
            return redirect('service-categories')->with("success","Service category updated successfully !");
    }

    public function disable($id) {
        $service_category = \App\ServiceCategory::find($id);
        $service_category->status = 1 - $service_category->status;
        $service_category->save();

        $text = ($service_category->status)?'enabled':'disabled';
        return redirect()->back()->with("success","Service category $text successfully !");
    }

    public function attributes()
    {
        return [
            'category' => 'Category Name',
        ];
    }

}
