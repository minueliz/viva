<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\MessageBag;
//use Srmklive\PayPal\Services\ExpressCheckout;
use Auth;
use Faker;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    public function redirectTo() 
    {
        /* generate URL dynamicaly */
        $user = Auth::user();
        
        if($user->hasRole('customer')){
            return '/';
        } elseif($user->hasRole('worker')) {
            return '/worker';
        } elseif($user->hasRole('admin')) {
            return '/admin';
        }
    }

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');        
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        $fields = array('type' => 'required',
                    'name' => ['required', 'string', 'max:255', 'alpha_spaces'],
                    'email' => ['required', 'string', 'email', 'max:255', 'unique:users', 'regex:/^[_a-z0-9-+]+(\.[_a-z0-9-+]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/i'],
                    'addr' => ['required', 'string', 'max:191'],
                    'did' => 'required',
                    'pin_code' => 'required|numeric|between:600000,699999',
                    'phone' => ['required', 'numeric', 'between:6000000000,9999999999'],
                    'sec_q' => 'required',
                    'sec_a' => ['required', 'string', 'max:191'],
                    'password' => ['required', 'string', 'min:8', 'confirmed']);

        if(isset($data['image'])) {
            $fields['image'] = 'mimes:jpg,jpeg,png';
        }
        if(!is_null($data['alt_phone'])) {
            $fields['alt_phone'] = ['numeric', 'between:6000000000,9999999999'];
        }
        if(isset($data['type']) && $data['type'] == '2') {
            $fields['image'] = 'required|mimes:jpg,jpeg,png';
            $fields['scat'] = 'required';
            $fields['per_hour_amount'] = ['required', 'digits_between:1,4'];
            $fields['exp_proof'] = 'required|mimes:jpg,jpeg,png';
            $fields['id_proof'] = 'required|mimes:jpg,jpeg,png';
        }
        if($data['type'] == '1') {
            $fields['cardName'] = ['required', 'string', 'max:191', 'alpha_spaces'];
            $fields['cardNumber'] = 'required|numeric|between:1000000000000000,9999999999999999';
            $fields['expiry'] = 'required|card_expiry';
            $fields['cvv'] = 'required|numeric|between:100,999';
        }
        
        return Validator::make($data, $fields, [], $this->attributes());
    }

    /**
     * Show the application registration form.
     *
     * @return \Illuminate\Http\Response
     */
    public function showRegistrationForm()
    {
        $categories = \App\ServiceCategory::where('status', 1)
                                            ->whereNull('parent_id')
                                            ->orderBy('id')->pluck('category', 'id');
        $districts = \App\District::where('status', 1)->orderBy('id')->pluck('district', 'id');
        $sec_qs = \App\SecQuestion::where('status', 1)->orderBy('id')->pluck('question', 'id');
        $cardTypes = \App\Credit::distinct()->pluck('type', 'type');
        return view('auth.register', ['districts' => $districts, 'sec_qs' => $sec_qs, 'categories' => $categories, 'cardTypes' => $cardTypes]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        $user = User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'api_token' => str_random(60),
        ]);

        if($data['type'] == '1') {
            $user->assignRole('customer');

            $balance = new \App\Credit;
            $balance->user_id = $user->id;
            $balance->card_no = $data['cardNumber'];
            $balance->expiry = $data['expiry'];
            $balance->cvv = $data['cvv'];
            $balance->name_on_card = $data['cardName'];
            $balance->type = $data['cardType'];
            $balance->balance = 200;
            $balance->save();
        } else
            $user->assignRole('worker');

        $imageName = ''; $expProof = ''; $idProof = ''; $sCat = null; $perHourAmt = 0;
        $userInf = new \App\UserInformation;
        $userInf->user_id = $user->id;
        $userInf->addr = $data['addr'];
        $userInf->district_id = $data['did'];
        $userInf->pin_code = $data['pin_code'];
        $userInf->phone = $data['phone'];
        $userInf->alt_phone = $data['alt_phone'];
        $userInf->sec_q = $data['sec_q'];
        $userInf->sec_a = $data['sec_a'];

        if(isset($data['image'])) {
            $imageName = 'p' . time() . '.' . $data['image']->getClientOriginalExtension();

            $data['image']->move(
                base_path() . '/public/images/profile/', $imageName
            );
        }
        if($data['type'] == '2') {
            $perHourAmt = $data['per_hour_amount'];
            $sCat = $data['scat'];

            $expProof = 'e' . time() . '.' . $data['exp_proof']->getClientOriginalExtension();

            $data['exp_proof']->move(
                base_path() . '/public/images/proofs/', $expProof
            );

            $idProof = 'a' . time() . '.' . $data['id_proof']->getClientOriginalExtension();

            $data['id_proof']->move(
                base_path() . '/public/images/proofs/', $idProof
            );
        }
        $userInf->per_hour_amount = $perHourAmt;
        $userInf->service_category = $sCat;
        $userInf->img = $imageName;
        $userInf->exp_proof = $expProof;
        $userInf->id_proof = $idProof;
        $userInf->save();

        //Add balance
        /*$faker = Faker\Factory::create();
        $credit = new \App\Credit;
        $credit->user_id = $user->id;
        $credit->card_no = $faker->creditCardNumber();
        $credit->expiry = $faker->creditCardExpirationDateString();
        $credit->cvv = rand(100, 999);
        $credit->name_on_card = $user->name;
        $credit->type = $faker->creditCardType;
        $credit->balance = 10000;
        $credit->save();*/

        /*$provider = new ExpressCheckout; 
        $data = [];
        $data['items'] = [
            [
                'name' => 'Product 1',
                'price' => 9.99,
                'qty' => 1
            ]
        ];
        $data['total'] = 9.99;
        $data['invoice_id'] = 1;
        $data['invoice_description'] = "Order #{$data['invoice_id']} Invoice";
        $data['return_url'] = url('/payment/success');
        $data['cancel_url'] = url('/cart');
        $response = $provider->setExpressCheckout($data);*/

        // if there is no link redirect back with error message
        //if (!$response['paypal_link']) {
            //return redirect('/')->with(['code' => 'danger', 'message' => 'Something went wrong with PayPal']);
        // For the actual error message dump out $response and see what's in there
        //}

        // redirect to paypal
        // after payment is done paypal
        // will redirect us back to $this->expressCheckoutSuccess
        //return redirect($response['paypal_link']);

        return $user;
    }

    public function register(Request $request)
    {
        $this->validator($request->all())->validate();

        event(new Registered($user = $this->create($request->all())));
        
        if ($user->hasRole('worker')) { 
            Auth::logout();
            $errors = new MessageBag;
            $errors->add('not-approved-reg', 'Thank you for the registration. Your account is under review by Administrator. You may login once the Administrator approves your registration.');
            return redirect('/login')
                    ->withErrors($errors);
        } else {
            $this->guard()->login($user);
        }

        return $this->registered($request, $user)
                        ?: redirect($this->redirectPath());
    }

    /**
     * Get the guard to be used during registration.
     *
     * @return \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected function guard()
    {
        return Auth::guard();
    }

    public function attributes()
    {
        return [
            'type' => 'User type',
            'alt_phone' => 'Alternate phone',
            'addr'  => 'Address',
            'pin_code' => 'Pin Code',
            'did' => 'District',
            'phone'  => 'Phone',
            'sec_q'  => 'Security question',
            'sec_a'  => 'Security answer',
            'exp_proof'  => 'Experience proof',
            'id_proof'  => 'Identity proof',
            'scat' => 'Service category',
            'per_hour_amount' => 'Per hour amount',
            'cardName' => 'Name on Card',
            'cardNumber' => 'Card Number',
            'expiry' => 'Expiry Date',
            'cvv' => 'CVV Code',
        ];
    }
}
