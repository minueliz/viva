<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\MessageBag;
use Cart;
use Illuminate\Http\Request;
use CartExtended;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function login(Request $request)
    {
        $this->validateLogin($request);

        // If the class is using the ThrottlesLogins trait, we can automatically throttle
        // the login attempts for this application. We'll key this by the username and
        // the IP address of the client making these requests into this application.
        if ($this->hasTooManyLoginAttempts($request)) {
            $this->fireLockoutEvent($request);

            return $this->sendLockoutResponse($request);
        }

        if ($this->attemptLogin($request)) {
            $user = $this->guard()->user();
            $user->generateToken();
            
            return $this->sendLoginResponse($request);
        }

        // If the login attempt was unsuccessful we will increment the number of attempts
        // to login and redirect the user back to the login form. Of course, when this
        // user surpasses their maximum number of attempts they will get locked out.
        $this->incrementLoginAttempts($request);

        return $this->sendFailedLoginResponse($request);
    }

    protected function authenticated($request, $user){ 
        if (Auth::user()->status != 1) { 
            Auth::logout();
            $errors = new MessageBag;
            $errors->add('blocked', 'Your account has been blocked by Administrator. For more information contact at support@homeservice.com');
            return redirect('/login')
                    ->withErrors($errors);
        } elseif (Auth::user()->worker_approved != 1 && Auth::user()->hasRole('worker')) { 
            Auth::logout();
            $errors = new MessageBag;
            $errors->add('not-approved', 'Your account is under review by Administrator. You may login once the Administrator approves your registration.');
            return redirect('/login')
                    ->withErrors($errors);
        }

        Cart::restore(Auth::user()->id);
        try {
            Cart::store(Auth::user()->id);
        } catch(\Gloudemans\Shoppingcart\Exceptions\CartAlreadyStoredException $e) {
            CartExtended::updateCartDb(Auth::user()->id);
        }

        if($user->hasRole('customer')){
            return redirect()->intended('/');
        } elseif($user->hasRole('worker')) {
            return redirect()->intended('/service-requests');
        } elseif($user->hasRole('admin')) {
            return redirect('/admin');
        }    
    }

    public function logout(Request $request)
    {
        $user = Auth::user();
        $user->api_token = null;
        $user->save();

        $this->guard()->logout();

        $request->session()->invalidate();

        return $this->loggedOut($request) ?: redirect('/');
    }
}
