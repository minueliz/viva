<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use Auth;
use Validator;
use App\Mail\WorkerApproved;
use Illuminate\Support\Facades\Mail;

class AdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth', 'role:admin']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $settings = \App\Setting::all();
        return view('admin.index', ['settings' => $settings]);
    }

    public function users()
    {
        $users = \App\User::role('customer')->leftJoin('user_informations', function($join) {
                                                      $join->on('user_informations.user_id', '=', 'users.id');  
                                                    })
                                            ->leftJoin('districts', function($join) {
                                                $join->on('user_informations.district_id', '=', 'districts.id');
                                            })
                                            ->select('users.id', 'users.name', 'users.status', 'user_informations.addr', 'user_informations.phone', 'districts.district')
                                            ->paginate(config('app.per_page'));

        if($users->isEmpty())
            return redirect()->route('admin.users');
        return view('admin.users', ['users' => $users]);
    }

    public function workers()
    {
        $users = \App\User::role('worker')->leftJoin('user_informations', function($join) {
                                                      $join->on('user_informations.user_id', '=', 'users.id');  
                                                    })
                                            ->leftJoin('districts', function($join) {
                                                $join->on('user_informations.district_id', '=', 'districts.id');
                                            })
                                            ->leftJoin('service_categories', function($join) {
                                                $join->on('user_informations.service_category', '=', 'service_categories.id');
                                            })
                                            ->select('users.id', 'users.name', 'users.status', 'user_informations.addr', 'user_informations.phone', 'user_informations.exp_proof', 'user_informations.id_proof', 'districts.district', 'service_categories.category', 'per_hour_amount', 'worker_approved')
                                            ->paginate(config('app.per_page'));

        if($users->isEmpty())
            return redirect()->route('admin.users');
        return view('admin.workers', ['users' => $users]);
    }

    public function disable($id) {
        $user = \App\User::find($id);
        $user->status = 1 - $user->status;
        $user->save();

        $text = ($user->status)?'enabled':'disabled';
        return redirect()->back()->with("success","Customer $text successfully !");
    }

    public function approveWorker($id, Request $request) {
        $user = \App\User::find($id);
        $user->worker_approved = 1;
        $user->save();

        Mail::to($user)->send(new WorkerApproved($user));

        return redirect()->back()->with("success","Worker approve successfully !");
    }

    public function userProfile($id) {
        $userInfo = \App\UserInformation::where('user_id', $id)->firstOrFail();
        $user = \App\User::findOrFail($id);
        return view('user.my-profile', ['userInfo' => $userInfo, 'customer' => $user->hasRole('customer'), 'worker' => $user->hasRole('worker')]);
    }

    public function reviews() {
        $reviews = \App\Review::orderBy('status', 'desc')
                                ->orderBy('created_at', 'desc')
                                ->paginate(config('app.per_page'));
        return view('admin.reviews', ['reviews' => $reviews]);
    }

    public function toggleReview($id, Request $request) {
        $status = $request->status;

        $review = \App\Review::find($id);
        $review->status = 1 - $review->status;
        $review->save();

        $text = ($review->status)?'approved':'disapproved';

        return redirect()->back()->with("success", "Review $text successfully !");
    }

    public function saveSettings(Request $request) {
        $fields = array('leave' => 'required|numeric|min:0|max:20');
        
        $validator = Validator::make($request->all(), $fields, [], $this->attributes());

        if ($validator->fails()) 
            return redirect('admin')
                        ->withErrors($validator)
                        ->withInput();
        
        \App\Setting::where('key', 'leave')
                        ->update(['value' => $request->leave]);

        \App\Setting::where('key', 'commision')
                        ->update(['value' => $request->commision]);

        return redirect('admin')->with("success","Settings saved successfully !");
    }

    public function commission(Request $request) {
        $orders = \App\Order::selectRaw('orders.*, sum(order_items.commision) as commision')
                                        ->join('order_items', function($join) 
                                             {
                                               $join->on('order_items.order_id', '=', 'orders.id');
                                               $join->where('order_items.item_type', 2);
                                             })
                                        ->orderBy('orders.created_at', 'desc')
                                        ->groupBy('orders.id');
                                        //->toSql();var_dump($orders);die;
                                        //->paginate(config('app.per_page'));
        if(!is_null($request->input('year')) && !is_null($request->input('month'))) {
            if($request->year != '0')
                $orders = $orders->whereYear('orders.created_at', $request->year);
            if($request->month != '0')
                $orders = $orders->whereMonth('orders.created_at', $request->month);
        } elseif(!is_null($request->input('year')) && $request->year != '0') {
            $orders = $orders->whereYear('orders.created_at', $request->year);
        } elseif(!is_null($request->input('month')) && $request->month != '0') {
            $orders = $orders->whereMonth('orders.created_at', $request->month);
        } 
        
        //$orderst = $orders->replicate;
        $orderst = $orders->get();
        $total = 0;
        foreach ($orderst as $value) {
            $total += $value->commision;
        }

        $orders = $orders->paginate(config('app.per_page'));
        return view('admin.commission', ['orders' => $orders, 'month' => $request->month, 'year' => $request->year, 'total' => $total]);
    }

    public function attributes()
    {
        return [
            'leave' => 'Number of Leaves',
        ];
    }
}
