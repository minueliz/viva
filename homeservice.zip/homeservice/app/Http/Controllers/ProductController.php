<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use Auth;
use Validator;

class ProductController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth', 'role:admin']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {   
        $products = \App\Product::paginate(config('app.per_page'));
        return view('products.index', ['products' => $products]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id) {
        // get the vehicle
        $product = \App\Product::findOrFail($id);
        return view('products.show', ['product' => $product]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {    
        $user = Auth::user();       
        $categories = \App\ProductCategory::where('status', 1)->orderBy('category')->pluck('category', 'id');
        return view('products.create', ['categories' => $categories]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store(Request $request)
    {        
        $fields = array('name' => 'required|alpha_spaces',
                        'description' => 'required|string',
                        'qty' => 'required|integer|between:1,999',
                        'amount' => 'required|numeric|min:1');
        if(isset($request['image']) && !is_null($request['image'])) {
            $fields['image'] = 'mimes:jpg,jpeg,png';
        }
        
        $validator = Validator::make($request->all(), $fields, [], $this->attributes());

        if ($validator->fails()) 
            return redirect('products/create')
                        ->withErrors($validator)
                        ->withInput();

        $ifExists = \App\Product::where(['name' => $request->name, 'product_category' => $request->cat])->first();
        if(!is_null($ifExists))  {
            $categories = \App\ProductCategory::where('status', 1)->orderBy('category')->pluck('category', 'id');

            return view('products.edit', ['product' => $ifExists, 'categories' => $categories, 'newQty' => $request->qty])->withErrors(["msg" => "Product with the same name exists! Please update the product to save changes."]);
        }
        
        $product = new \App\Product;
        $product->product_category = $request->cat;
        $product->name = $request->name;
        $product->description = $request->description;
        $product->qty = $request->qty;
        $product->amount = $request->amount;

        $imageName = '';
        if(isset($request['image'])) {
            $imageName = 'p' . time() . '.' . $request['image']->getClientOriginalExtension();

            $request['image']->move(
                base_path() . '/public/images/products/', $imageName
            );
        }
        $product->img = $imageName;

        $product->save();
        return redirect('products/'.$product->id)->with("success","Product saved successfully !");
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        $product = \App\Product::findOrFail($id);
        $categories = \App\ProductCategory::where('status', 1)->orderBy('category')->pluck('category', 'id');

        return view('products.edit', ['product' => $product, 'categories' => $categories, 'newQty' => 0]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update($id, Request $request)
    {
        $fields = array('name' => 'required|alpha_spaces',
                        'description' => 'required|string',
                        'qty' => 'required|integer|between:1,999',
                        'amount' => 'required|numeric|min:1');
        if(isset($request['image']) && !is_null($request['image'])) {
            $fields['image'] = 'mimes:jpg,jpeg,png';
        }
        
        $validator = Validator::make($request->all(), $fields, [], $this->attributes());        

        if ($validator->fails()) 
            return redirect('products/'.$id.'/edit')
                        ->withErrors($validator)
                        ->withInput();

        $product = \App\Product::find($id);
        $product->product_category = $request->cat;
        $product->name = $request->name;
        $product->description = $request->description;
        $product->qty = $request->qty;
        $product->amount = $request->amount;

        $imageName = '';
        if(!is_null($request['image'])) {
            $imageName = 'p' . time() . '.' . $request['image']->getClientOriginalExtension();

            $request['image']->move(
                base_path() . '/public/images/products/', $imageName
            );
            $product->img = $imageName;
        }        
        
        $product->save();
        return redirect('products')->with("success","Product updated successfully !");
    }

    public function attributes()
    {
        return [
            'name' => 'Name',
            'description' => 'Description',
            'qty' => 'Quantity',
            'amount' => 'Amount',
        ];
    }

    public function disable($id) {
        $product = \App\Product::find($id);
        $product->status = 1 - $product->status;
        $product->save();

        $text = ($product->status)?'enabled':'disabled';
        return redirect()->back()->with("success","Product $text successfully !");
    }
}
