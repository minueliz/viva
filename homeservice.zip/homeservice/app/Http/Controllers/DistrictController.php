<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use Auth;
use Validator;

class DistrictController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth', 'role:admin']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {   
        $districts = \App\District::orderBy('status', 'desc')->paginate(config('app.per_page'));
        /*if($districts->isEmpty())
            return redirect()->route('districts.index');*/
        
        return view('districts.index', ['districts' => $districts]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {    
        return view('districts.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store(Request $request)
    {        
        $fields = array('district' => 'required|alpha');
        
        $validator = Validator::make($request->all(), $fields, [], $this->attributes());

        if ($validator->fails()) 
            return redirect('districts/create')
                        ->withErrors($validator)
                        ->withInput();
        
        $district = new \App\District;
        $district->district = $request->district;

        $district->save();
        return redirect('districts/')->with("success","District saved successfully !");
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        $district = \App\District::findOrFail($id);
        
        return view('districts.edit', ['district' => $district]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update($id, Request $request)
    {
        $validator = Validator::make($request->all(), [
            'district' => 'required|alpha',
        ], [], $this->attributes());

        if ($validator->fails()) 
            return redirect('districts/'.$id.'/edit')
                        ->withErrors($validator)
                        ->withInput();

        $district = \App\District::find($id);
        $district->district = $request->district;
        
        $district->save();
        return redirect('districts')->with("success","District updated successfully !");
    }

    public function attributes()
    {
        return [
            'district' => 'District Name',
        ];
    }

    public function disable($id) {
        $district = \App\District::find($id);
        $district->status = 1 - $district->status;
        $district->save();

        $text = ($district->status)?'enabled':'disabled';
        return redirect()->back()->with("success","District $text successfully !");
    }
}
