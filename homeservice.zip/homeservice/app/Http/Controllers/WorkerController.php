<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use Auth;
use Validator;
use DateTime;
use App\Mail\PaymentRequest;
use App\Mail\ServiceRejected;
use Illuminate\Support\Facades\Mail;

class WorkerController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth', 'role:worker']);
    }

    public function index()
    {
        return view('worker.index');
    }
    
    public function serviceRequests() {
        $serviceRequests = \App\OrderItem::where('item_type', 2)
                                            ->where('item_id', Auth::User()->id)
                                            ->orderBy('created_at', 'desc')
                                            ->paginate(config('app.per_page'));
        $servStatuses = [
                            0 => 'Worker notification sent',
                            1 => 'Order Placed',
                            4 => 'Invoice generated',
                            5 => 'Completed',
                            6 => 'Cancelled',
                            7 => 'Worker confirmed order',
                            8 => 'User requested refund',
                            9 => 'Worker requested payment',
                            10 => 'Refunded',
                            11 => 'Refunded from deposit'
                        ];                                            
        return view('worker.service-requests', ['serviceRequests' => $serviceRequests, 'servStatuses' => $servStatuses]);
    }

    public function serviceRequest($id) {
        $serviceRequest = \App\OrderItem::where('item_id', Auth::user()->id)->findOrFail($id);
        $servStatuses = [
                            0 => 'Worker notification sent',
                            1 => 'Order Placed',
                            4 => 'Invoice generated',
                            5 => 'Completed',
                            6 => 'Cancelled',
                            7 => 'Worker confirmed order',
                            8 => 'User requested refund',
                            9 => 'Worker requested payment',
                            10 => 'Refunded',
                            11 => 'Refunded from deposit'
                        ];
        for ($i=config('app.startH'); $i <= config('app.endH'); $i++) { 
            $hours[] = ['key' => sprintf('%02d', $i), 'value' => sprintf('%02d', $i)];
        }
        $hours = collect($hours);
        $hours = $hours->pluck('key', 'value');
        $bDate = date('d-m-Y', strtotime($serviceRequest->service_slot_from));
        $_slotFrom = date('H', strtotime($serviceRequest->service_slot_from));
        $_slotTo = date('H', strtotime($serviceRequest->service_slot_to));
        return view('worker.service-request', ['serviceRequest' => $serviceRequest, 'servStatuses' => $servStatuses, 'bDate' => $bDate, 'hours' => $hours, '_slotFrom' => $_slotFrom, '_slotTo' => $_slotTo]);
    }

    public function updateSchedule($id, Request $request) {
        $serv = \App\OrderItem::where('item_id', Auth::user()->id)
                                ->findOrFail($id);
        if(isset($request->cancel)) {
            $serv->status = 6;
            $serv->save();

            $user = \App\User::find($serv->order->user_id);
            Mail::to($user)->send(new ServiceRejected($user, $serv));

            return redirect()->back()->with("success","Service request has been rejected.");
        }

        $bDate = join('-', array_reverse( explode('-', $request->bDate)));
        $slotFrom = $bDate . ' ' . $request->slotFrom . ':00';
        $slotTo = $bDate . ' ' . $request->slotTo . ':00';

        $ifExists = \App\User::select('users.*')
                                    ->where('worker_approved', 1)
                                    ->leftJoin('order_items', function($join) use($slotFrom, $slotTo, $bDate)
                                         {
                                           $join->on('order_items.item_id', '=', 'users.id');
                                           $join->where('order_items.item_type', 2);
                                           $join->WhereRaw('(
                        (order_items.service_slot_from >= ? and order_items.service_slot_from < ?) or 
                        (order_items.service_slot_to > ? and  order_items.service_slot_to <= ?))', [$slotFrom, $slotTo, $slotFrom, $slotTo]);
                                           $join->whereIn('order_items.status', [7, 1]);
                                         })
                                    ->leftJoin('leaves', function($join) use($bDate)
                                         {
                                           $join->on('leaves.user_id', '=', 'users.id');
                                           $join->where('leaves.status', 2);
                                           $join->whereRaw('? between leaves.from and leaves.to', [$bDate]);
                                         })
                                    ->where('users.id', Auth::user()->id)
                                    ->where('order_items.id', '<>', $id)
                                    ->whereNull('leaves.id')
                                    //->toSql();dd($ifExists);die;
                                    ->get();    
        if(count($ifExists)) {
            return redirect()->back()
                                ->withErrors(['error' => 'The service slot is not available.'])
                                ->withInput();
        }
        
        $serv->service_slot_from = $slotFrom;
        $serv->service_slot_to = $slotTo;
        $serv->qty = round((strtotime($slotTo) - strtotime($slotFrom))/3600, 1);
        $serv->amount = $serv->qty * Auth::user()->userinformation->per_hour_amount;

        $commision = \App\Setting::find('2');
        $serv->commision = floatval($commision->value * $serv->qty * Auth::user()->userinformation->per_hour_amount) / 100;
        $serv->status = 7;
        $serv->save();

        //Send mail
        $user = \App\User::find($serv->order->user_id);
        Mail::to($user)->send(new PaymentRequest($user, $serv));

        $serv->order()
                ->update([
                        'amount' => $serv->amount + $serv->order->amount
                    ]);

        return redirect()->back()->with("success","Payment request has been sent successfully to the customer.");
    }

    public static function canGenInvoice($serviceOrder) {
        $endDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $serviceOrder->service_slot_to);
        $now = DateTime::createFromFormat('Y-m-d H:i:s', date('Y-m-d H:i:s'));
        if($serviceOrder->status == 1 && $endDateTime < $now && $serviceOrder->status != 8)
            return true;
        else
            return false;
    }

    public static function canRequestPayment($serviceOrder) {
        $endDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $serviceOrder->service_slot_to);
        $now = DateTime::createFromFormat('Y-m-d H:i:s', date('Y-m-d H:i:s'));
        if($serviceOrder->status == 4 && $endDateTime < $now)
            return true;
        else
            return false;
    }

    public function cancelLeave($id, Request $request) {
        $leave = \App\Leave::find($id);
        $leave->status = 4;
        $leave->save();

        return redirect()->back()->with("success", "Leave cancelled successfully !");
    }

    public function saveInvoice(Request $request) {
        $item = \App\OrderItem::findOrFail($request->itemId);

        $invoice = new \App\ServiceInvoice;
        $invoice->item_id = $item->id;
        $invoice->hours = $request->hours;
        $invoice->additional_purchases = $request->additional;
        $invoice->additional_amount = $request->additionalAmt;

        $commision = \App\Setting::find('2');
        $invoice->commision = floatval(Auth::user()->userinformation->per_hour_amount * $request->hours * $commision->value) / 100;

        $invoice->total = floatval($request->hours * Auth::User()->userinformation->per_hour_amount) + $request->additionalAmt;

        $invoice->save();

        $item->amount += $invoice->total;
        $item->commision += $invoice->commision;
        $item->order()
                ->update([
                        'amount' => $invoice->total + $item->order->amount
                    ]);
        /*if(!$invoice->total)
            $item->status = 5;
        else*/
            $item->status = 4;
        $item->save();

        return redirect()->back()->with("success","Invoice has been sent successfully.");
    }
}