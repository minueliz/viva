<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use Auth;
use Validator;

class SecQuestionController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth', 'role:admin']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {   
        $sec_questions = \App\SecQuestion::orderBy('status', 'desc')->paginate(config('app.per_page'));
        /*if($sec_questions->isEmpty())
            return redirect()->route('security-questions.index');*/
        
        return view('sec_questions.index', ['sec_questions' => $sec_questions]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {    
        return view('sec_questions.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store(Request $request)
    {        
        $fields = array('sec_question' => 'required|alpha_spaces_q');
        
        $validator = Validator::make($request->all(), $fields, [], $this->attributes());

        if ($validator->fails()) 
            return redirect('security-questions/create')
                        ->withErrors($validator)
                        ->withInput();
        
        $sec_question = new \App\SecQuestion;
        $sec_question->question = $request->sec_question;

        $sec_question->save();
        return redirect('security-questions/')->with("success","Security Question saved successfully !");
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        $sec_question = \App\SecQuestion::findOrFail($id);
        
        return view('sec_questions.edit', ['sec_question' => $sec_question]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update($id, Request $request)
    {
        $validator = Validator::make($request->all(), [
            'question' => 'required|alpha_spaces_q',
        ], [], $this->attributes());

        if ($validator->fails()) 
            return redirect('security-questions/'.$id.'/edit')
                        ->withErrors($validator)
                        ->withInput();

        $sec_question = \App\SecQuestion::find($id);
        $sec_question->question = $request->question;
        
        $sec_question->save();
        return redirect('security-questions')->with("success","Security Question updated successfully !");
    }

    public function attributes()
    {
        return [
            'sec_question' => 'Security Question',
            'question' => 'Security Question',
        ];
    }

    public function disable($id) {
        $sec_question = \App\SecQuestion::find($id);
        $sec_question->status = 1 - $sec_question->status;
        $sec_question->save();

        $text = ($sec_question->status)?'enabled':'disabled';
        return redirect()->back()->with("success","Security Question $text successfully !");
    }
}