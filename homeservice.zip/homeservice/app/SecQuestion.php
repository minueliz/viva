<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SecQuestion extends Model
{
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id', 'question', 'status'
    ];    

    protected $primaryKey = 'id';

    protected $attributes = [
        'status' => 1
    ];

}
