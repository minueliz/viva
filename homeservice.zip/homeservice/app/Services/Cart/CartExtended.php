<?php

namespace App\Services\Cart;

use Gloudemans\Shoppingcart\Cart;
use Illuminate\Database\DatabaseManager;

class CartExtended extends Cart
{
	/**
     * Get the database table name.
     *
     * @return string
     */
    private function getTableName()
    {
        return config('cart.database.table', 'shoppingcart');
    }

	/**
     * Get the database connection.
     *
     * @return \Illuminate\Database\Connection
     */
    private function getConnection()
    {
        $connectionName = $this->getConnectionName();

        return app(DatabaseManager::class)->connection($connectionName);
    }

	/**
     * Get the database connection name.
     *
     * @return string
     */
    private function getConnectionName()
    {
        $connection = config('cart.database.connection');

        return is_null($connection) ? config('database.default') : $connection;
    }

	/**
     * Update the current instance of the cart.
     *
     * @param mixed $identifier
     * @return void
     */
    public function updateCartDb($identifier)
    {
        $content = $this->getContent();

        $this->getConnection()->table($this->getTableName())
        	->where(['identifier' => $identifier,
        			 'instance' => $this->currentInstance()
        			 ])
        	->update([
	            'content' => serialize($content)
	        ]);

        //$this->events->fire('cart.stored');
    }

    public function clearCartDb($identifier)
    { 
        $content = $this->getContent();
//var_dump($identifier, $this->currentInstance());
        $this->getConnection()->table($this->getTableName())            
            ->where([
                'identifier' => $identifier,
                'instance' => $this->currentInstance()
            ])
            ->delete();
//var_dump($r); die;
        //$this->events->fire('cart.stored');
    }
}