<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id', 'order_id', 'item_id', 'item_type', 'qty', 'amount', 'commision', 'status'
    ];

    protected $primaryKey = 'id';

    public $table = "order_items";

    public function product()
    {
        return $this->hasOne('App\Product', 'id', 'item_id');
    }

    public function worker()
    {
        return $this->hasOne('App\User', 'id', 'item_id');
    }

    public function serviceSubCat()
    {
        return $this->hasOne('App\ServiceCategory', 'id', 'service_subCat');
    }

    public function serviceslot()
    {
        return $this->hasOne('App\ServiceSlot', 'id', 'service_slot');
    }

    public function invoice()
    {
        return $this->hasOne('App\ServiceInvoice', 'item_id', 'id');
    }

    public function order()
    {
        return $this->belongsTo('App\Order', 'order_id', 'id');
    }
}