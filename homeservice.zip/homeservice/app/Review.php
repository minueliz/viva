<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id', 'user_id', 'item_id', 'worker_id', 'product_id', 'rating', 'comment', 'status'
    ];

    protected $primaryKey = 'id';

    protected $attributes = [
        'status' => 0,
    ];

    public function user()
    {
        return $this->hasOne('App\User', 'id', 'user_id');
    }

    public function worker()
    {
        return $this->hasOne('App\User', 'id', 'worker_id');
    }

    public function orderItem()
    {
        return $this->hasOne('App\OrderItem', 'id', 'item_id');
    }

    public function product()
    {
        return $this->hasOne('App\Product', 'id', 'product_id');
    }
}