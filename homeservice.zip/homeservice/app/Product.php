<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{
    use SoftDeletes;
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id', 'name', 'description', 'qty', 'amount', 'img', 'status'
    ];    

    protected $primaryKey = 'id';

    protected $attributes = [
        'deleted_at' => null
    ];

    public function category()
    {
        return $this->belongsTo('App\ProductCategory', 'product_category', 'id');
    }

    public function reviews()
    {
        return $this->hasMany('App\Review', 'product_id', 'id');
    }
}
