<?php namespace App\Providers;

use View;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Auth;
use Cart;

class AppCommonsServiceProvider extends ServiceProvider {

    /**
     * Register bindings in the container.
     *
     * @return void
     */
    public function boot()
    {
        // Using Closure based composers...
        
        View::composer('*', function($view) 
        {
            $cartCon = Cart::content();
            $qty = 0;
            foreach ($cartCon as $key => $item) { 
                if(get_class($item->model) == 'App\Product') $qty+=$item->qty;
                else $qty++;

            }
            $addr = '';
            if(Auth::check()) {
                $addr = Auth::user()->userinformation->addr . "\n" . Auth::user()->userinformation->district->district . "\n" . Auth::user()->userinformation->pin_code;
            }
            $view->with([
                'leaveCount' => \App\Leave::where('status', 1)->get()->count(),
                'img' => Auth::check()?Auth::user()->userinformation->img:null,
                'qty' => $qty,
                'addr' => $addr
                ]);
        });
    }

    /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {
        //
    }

}