<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ServiceSlot extends Model
{
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id', 'slot', 'status'
    ];

    protected $primaryKey = 'id';

    public $table = "service_slots";

    protected $attributes = [
        'status' => 1,
    ];

}