<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ServiceCategory extends Model
{
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id', 'parent_id', 'category', 'img', 'status'
    ];

    protected $primaryKey = 'id';

    public $table = "service_categories";

    protected $attributes = [
        'status' => 1,
    ];

    public function parent()
    {
        return $this->hasOne('App\ServiceCategory', 'id', 'parent_id');
    }
}
