<html>

<head>
<link href="css/style5.css" rel="stylesheet" type="text/css" media="all"/>
</head>
@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
        <body   class="b" >
            <div class="card">
                <div class="card-header">{{ __('Register') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('register') }}" enctype="multipart/form-data" class="registration">
                        @csrf
                        <div class="form-group row">
                              {{ Form::label('type', 'Type', array('class' => 'col-md-4 control-label text-md-right')) }}
                              <div class="col-md-4">
                                Customer {{ Form::radio('type', 1, (old('type')[0] == '1')?true:false, ['class' => $errors->has('type') ? 'form-control is-invalid' : 'form-control', 'id' => "t1"]) }}
                                Worker {{ Form::radio('type', 2, (old('type')[0] == '2')?true:false, ['class' => $errors->has('Type') ? 'form-control is-invalid' : 'form-control', 'id' => 't2']) }}
                                @if ($errors->has('type'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('type') }}</strong>
                                    </span>
                                @endif
                              </div>
                        </div>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ old('name') }}" required >

                                @if ($errors->has('name'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" required>

                                @if ($errors->has('email'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="addr" class="col-md-4 col-form-label text-md-right">{{ __('Address') }}</label>

                            <div class="col-md-6">
                                <textarea id="addr" type="text" class="form-control{{ $errors->has('addr') ? ' is-invalid' : '' }}" name="addr" required >{{ old('addr') }}</textarea>

                                @if ($errors->has('addr'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('addr') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                              {{ Form::label('did', 'District', array('class' => 'col-md-4 control-label text-md-right')) }}
                              <div class="col-md-4">
                                {!! Form::select('did', $districts, null, ['class' => $errors->has('did') ? 'form-control is-invalid' : 'form-control']) !!}
                              </div>
                        </div>

                        <div class="form-group row">
                            <label for="pin_code" class="col-md-4 col-form-label text-md-right">{{ __('Pin code') }}</label>

                            <div class="col-md-4">
                                <input id="pin_code" type="text" class="form-control{{ $errors->has('pin_code') ? ' is-invalid' : '' }}" name="pin_code" value="{{ old('pin_code') }}" required minLength="6" maxLength="6" >

                                @if ($errors->has('pin_code'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('pin_code') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>                        

                        <div class="form-group row">
                              {{ Form::label('phone', 'Phone', array('class' => 'col-md-4 control-label text-md-right')) }}
                              <div class="col-md-4">
                                {{ Form::text('phone', Request::old('phone'), array('class' => $errors->has('phone') ? 'form-control is-invalid' : 'form-control', 'placeholder' => "0764344899", 'minLength' => 10, 'maxLength' => 15)) }}
                                @if ($errors->has('phone'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('phone') }}</strong>
                                    </span>
                                @endif
                              </div>
                        </div>

                        <div class="form-group row insertAfter1">
                              {{ Form::label('alt_phone', 'Alternate Phone', array('class' => 'col-md-4 control-label text-md-right')) }}
                              <div class="col-md-4">
                                {{ Form::text('alt_phone', Request::old('alt_phone'), array('class' => $errors->has('alt_phone') ? 'form-control is-invalid' : 'form-control', 'placeholder' => "0764344890", 'minLength' => 10, 'maxLength' => 15)) }}
                                @if ($errors->has('alt_phone'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('alt_phone') }}</strong>
                                    </span>
                                @endif
                              </div>
                        </div>                        

                        <div class="form-group row">
                              {{ Form::label('sec_q', 'Security question', array('class' => 'col-md-4 control-label text-md-right')) }}
                              <div class="col-md-4">
                                {!! Form::select('sec_q', $sec_qs, null, ['class' => $errors->has('sec_q') ? 'form-control is-invalid' : 'form-control']) !!}
                              </div>
                        </div>

                        <div class="form-group row insertAfter">
                              {{ Form::label('sec_a', 'Answer', array('class' => 'col-md-4 control-label text-md-right')) }}
                              <div class="col-md-4">
                                {{ Form::text('sec_a', Request::old('sec_a'), array('class' => $errors->has('sec_a') ? 'form-control is-invalid' : 'form-control', 'placeholder' => "Blue")) }}
                                @if ($errors->has('sec_a'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('sec_a') }}</strong>
                                    </span>
                                @endif
                              </div>
                        </div>

                        <div class="form-group row">
                              {{ Form::label('image', 'Profile picture', array('class' => 'col-md-4 control-label text-md-right')) }}
                              <div class="col-md-4">
                                {{ Form::file('image', array('class' => $errors->has('image') ? 'form-control is-invalid' : 'form-control')) }}
                                @if ($errors->has('image'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('image') }}</strong>
                                    </span>
                                @endif
                              </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row payment">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Confirm Password') }}</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Register') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script src="{{ asset('js/jquery.min.js') }}"></script>
<script type="text/javascript">
$(function(){
    tA = `<div class="form-group row inserted">
                      {{ Form::label('exp_proof', 'Experience proof', array('class' => 'col-md-4 control-label text-md-right')) }}
                      <div class="col-md-4">
                        {{ Form::file('exp_proof', array('class' => $errors->has('exp_proof') ? 'form-control is-invalid' : 'form-control')) }}
                        @if ($errors->has('exp_proof'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('exp_proof') }}</strong>
                            </span>
                        @endif
                      </div>
                  </div>
                  <div class="form-group row inserted">
                      {{ Form::label('id_proof', 'Indentity proof', array('class' => 'col-md-4 control-label text-md-right')) }}
                      <div class="col-md-4">
                        {{ Form::file('id_proof', array('class' => $errors->has('id_proof') ? 'form-control is-invalid' : 'form-control')) }}
                        @if ($errors->has('id_proof'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('id_proof') }}</strong>
                            </span>
                        @endif
                      </div>
                  </div>
                  <div class="form-group row inserted">
                      {{ Form::label('per_hour_amount', 'Per hour amount', array('class' => 'col-md-4 control-label text-md-right')) }}
                      <div class="col-md-4">
                        <input id="per_hour_amount" type="number" min="1" class="form-control{{ $errors->has('per_hour_amount') ? ' is-invalid' : '' }}" name="per_hour_amount" value="{{ old('per_hour_amount') }}" required minLength="1" maxLength="4" >
                        @if ($errors->has('per_hour_amount'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('per_hour_amount') }}</strong>
                            </span>
                        @endif
                      </div>
                  </div>`;
    tA1 = `<div class="form-group row inserted">
              {{ Form::label('scat', 'Service category', array('class' => 'col-md-4 control-label text-md-right')) }}
              <div class="col-md-4">
                {!! Form::select('scat', $categories, null, ['class' => $errors->has('scat') ? 'form-control is-invalid' : 'form-control']) !!}
              </div>
          </div>`;
    tA2 = `<div class="col-xs-12 col-md-7 mt-4 row">
            <div class="panel panel-default appended">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        Payment Details
                    </h3>
                </div>
                <div class="panel-body">
                    <div class="form-group">
                        <label for="cardName">
                            Security deposit, 200/-</label><br>
                        <label for="cardName">
                            Name on Card</label>
                        <div class="input-group">
                            {{ Form::text('cardName', Request::old('cardName'), array('class' => $errors->has('cardName') ? 'form-control is-invalid' : 'form-control', 'placeholder' => "", 'required')) }}
                            @if ($errors->has('cardName'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('cardName') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="cardNumber">
                            Card Number</label>
                        <div class="input-group">
                            {{ Form::text('cardNumber', Request::old('cardNumber'), array('class' => $errors->has('cardNumber') ? 'form-control numeric is-invalid' : 'form-control numeric', 'placeholder' => "4800 1234 5678 9876", 'required', 'minlength' => 14, 'maxlength' => 16)) }}
                            <span class="input-group-addon"><span class="fa fa-lock"></span></span>
                            @if ($errors->has('cardNumber'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('cardNumber') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 col-md-12">
                            <div class="form-group">
                                <label for="expiry">
                                    Card Type</label>
                                <div class="col-xs-6 col-lg-6 pl-ziro">
                                    {!! Form::select('cardType', $cardTypes, Request::old('cardType'), ['class' => 'form-control']) !!}
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-7 col-md-7">
                            <div class="form-group">
                                <label for="expiry">
                                    Expiry Date</label>
                                <div class="col-xs-6 col-lg-6 pl-ziro">
                                    {{ Form::text('expiry', Request::old('expiry'), array('class' => $errors->has('expiry') ? 'form-control is-invalid' : 'form-control', 'placeholder' => "MM/YY", 'required', 'maxlength' => 5 )) }}
                                    @if ($errors->has('expiry'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('expiry') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-5 col-md-5 pull-right">
                            <div class="form-group">
                                <label for="cvCode">
                                    CVV</label>
                                <div class="col-xs-7 col-lg-7 pl-ziro">
                                    {{ Form::text('cvv', Request::old('cvv'), array('class' => $errors->has('cvv') ? 'form-control numeric is-invalid' : 'form-control numeric', 'placeholder' => "CVV", 'minlength' => 3, 'maxlength' => 3, 'required', 'min' => 1 )) }}
                                    @if ($errors->has('cvv'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('cvv') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
           </div>`;
    $('input[type="radio"]').change(function(){ 
        if($(this).val() == 2) {
            $('.insertAfter1').after(tA1)
            $('.insertAfter').after(tA)
            $('.appended').remove() 
        } else {
            $('.payment').after(tA2)
            $('.inserted').remove() 
        }
    });

    if($('input[type="radio"]:checked').val() == 2) {
        $('.insertAfter1').after(tA1)
        $('.insertAfter').after(tA) 
        $('.appended').remove() 
    } else if($('input[type="radio"]:checked').val() == 1) {
        $('.payment').after(tA2)
        $('.inserted').remove() 
    } else {        
        $('.inserted').remove() 
    }
    $('body').on('keypress', '.numeric', function(e){
        if(! /^\d*$/.test(e.key)) {
            return false;
        }
    })

    $('body').on('keypress', 'input[name="expiry"]', function(e){
        if(! /^\d*$/.test(e.key)) {
            return false;
        }

        if($(this).val().length >= 2 && e.keyCode !== 46 && e.keyCode !== 8) {
            if($(this).val().indexOf('/') === -1)
                $(this).val($(this).val().substr(0, 2) + '/' + $(this).val().substr(2))
        }

        if($(this).val().length >= 5)
            $(this).val($(this).val().substr(0, 5)) 
    })

    $('body').on('paste', 'input[name="expiry"]', function(e){
        return false;
    })

     $('.is-invalid').focus();
});
</script>

@endsection