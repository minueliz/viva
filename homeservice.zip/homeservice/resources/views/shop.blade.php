@extends('layouts.app')
@section('title', '| Edit Profile')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-12">

			{{ Form::open(['url' => '/shop', 'method' => 'get', 'style' => 'width:100%']) }}
			<fieldset class="search">
				  <div class="form-group row">
			    <div class="col-md-3">
			      {{ Form::text('keyword', $keyword, array('class' => 'form-control', 'id' => 'keyword', 'placeholder' => 'Product name or description')) }}
			    </div>
			  	<div class="col-md-3">
			    	{!! Form::select('cat', $prodCats, $cat, ['class' => 'form-control m-bot15', 'placeholder' => 'Category', 'id' => 'cat']) !!}
			  	</div>
			  	{{ Form::submit('Search', array('class' => 'btn btn-primary')) }}
			  </div>
			</fieldset>
			{{ Form::close() }}
            

            <h1>Products</h1>
            <div class="row">
            @foreach($products as $product)
            	<div class="col-md-3 singleProd">
            	  <div class="w-100 prod-list-img">
					  @if(!empty($product->img))
		                  <img class="img-responsive" src="{{URL::asset('images/products')}}/{{$product->img}}" >
		              @else
		                  <img class="img-responsive" src="{{URL::asset('images/products')}}/214x150.png" >
		              @endif
		          </div>  
				  <div class="product-short">
				    <h5 class="prod-title">
				    	<a href="{{ URL::to('product/' .  Str::slug($product->name) . '/' . $product->id) }}">
				    		{{ $product->name }}
				    	</a>
				    </h5>
				    <h6 class="prod-desc">{{ ucfirst((strlen($product->description) > 70)?substr($product->description, 0, 70).'...':$product->description) }}</h6>
				    <div class="row addToCart">
				    	@if($product->qty)
					    	<div class="prod-amount col">{!! config('app.currency') !!}{{ number_format($product->amount, 2) }}</div>
					    	{{ Form::open(array('url' => 'cart/' . $product->id, 'class' => 'col-md-8')) }}
	                          {{ Form::hidden('_method', 'POST') }}
	                          {!! Form::select('qty'.$product->id, array(1 => 1, 2 => 2, 3 => 3, 4 => 4, 5 => 5), Request::old('qty'), ['class' => $errors->has('qty'.$product->id) ? 'form-control float-left is-invalid' : 'form-control float-left', $errors->has('qty'.$product->id)?'autofocus':'']) !!}
                              {{ Form::submit('Add to cart', array('class' => 'btn btn-primary form-inline', (session('success'.$product->id))?'autofocus':'')) }}
                              <span class="invalid-feedback mt-2 w-100" role="alert">
	                                <strong>{{ $errors->first('qty'.$product->id) }}</strong>
	                          </span>
	                        {{ Form::close() }}
                            @if (session('success'.$product->id))
						        <div class="alert alert-success ml-3 mr-3 mt-2 w-100">
						            {{ session('success'.$product->id) }}
						        </div>
						    @endif
	                    @else
	                    	<div class="col-md-12 out-of-stock">Out of stock</div>
	                    @endif
				    </div>
				  </div>
				</div>
            @endforeach
            @if(!count($products))
	            <div class="col-md-12">
	            	No products found!
	            </div>
            @else
            	<div class="col-md-12">
            		{!! $products->appends(\Request::except('page'))->render() !!}
            	</div>
            @endif
          	</div>
        </div>
    </div>
</div> 
@endsection