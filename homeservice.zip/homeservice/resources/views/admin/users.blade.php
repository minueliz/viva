@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            @include('layouts.sidebar')
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Customers</div>

                <div class="card-body">
                    @if (session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                    @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif 
                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          <th scope="col">Name</th>
                          <th scope="col">Address</th>
                          <th scope="col">District</th>
                          <th scope="col">Phone</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                          @foreach($users as $user)
                          <tr>
                              <td>
                                <a href="{{ URL::to('profile/' . $user->id) }}">{{ $user->name }}</a>
                              </td>
                              <td>{{ $user->addr }}</td>
                              <td>{{ $user->district }}</td>
                              <td>{{ $user->phone }}</td>
                              <td>
                                {{ Form::open(array('url' => 'admin/disable/' . $user->id, 'class' => 'pull-right')) }}
                                    {{ Form::hidden('_method', 'POST') }}
                                    
                                        {{ Form::submit(($user->status)?'Disable':'Enable', array('class' => ($user->status)?'btn btn-sm btn-warning':'btn btn-sm btn-primary')) }}

                                  {{ Form::close() }}
                              </td>
                            </tr>
                          @endforeach
                        </tbody>
                    </table>
                  {!! $users->appends(\Request::except('page'))->render() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
