@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            @include('layouts.sidebar')
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">
                  Reviews
                </div>

                <div class="card-body">
                    @if (session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                    @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif 
                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          <th scope="col">Order #ID</th>
                          <th scope="col">User</th>
                          <th scope="col" width="106px">Date</th>
                          <th scope="col">Comment</th>
                          <th scope="col" width="120px">Rating</th>
                          <th scope="col">Product</th>
                          <th scope="col">Worker</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>                        
                          @foreach($reviews as $review)
                          <tr>
                            <td>
                              <a href="{{ URL::to('order-details/' . $review->orderItem->order_id) }}">#{{ str_pad($review->orderItem->order_id, 4, '0', STR_PAD_LEFT) }}</a>
                            </td>
                            <td>
                              {{ $review->user->name }}
                            </td>
                            <td>
                              {{ date('d-m-Y', strtotime($review->created_at)) }}
                            </td>
                            <td>
                              {!! nl2br($review->comment) !!}
                            </td>
                            <td>
                              @for($i=$review->rating; $i<5; $i++)
                                <span><span class="text-warning far fa-star" aria-hidden="true"></span></span>
                              @endfor
                              @for($i=1; $i<=$review->rating; $i++)
                                <span><i class="text-warning fa fa-star"></i></span>
                              @endfor
                            </td>
                            <td>
                              {{ ($review->product_id)?$review->product->name:'--' }}
                            </td>
                            <td>
                              {{ ($review->worker_id)?$review->worker->name:'--' }}
                            </td>
                            <td>
                              {{ Form::open(array('url' => 'review/toggle/' . $review->id, 'class' => 'pull-right')) }}
                                {{ Form::hidden('_method', 'PUT') }}
                                    {{ Form::submit(($review->status)?'Disable':'Enable', array('class' => ($review->status)?'btn btn-sm btn-warning':'btn btn-sm btn-primary')) }}
                              {{ Form::close() }} 
                            </td>
                          </tr>
                          @endforeach
                          @if(!count($reviews))
                            <tr class="no-rec">
                              <td colspan="7">No records!</td>
                            </tr>
                          @endif
                        </tbody>
                    </table>
                  {!! $reviews->appends(\Request::except('page'))->render() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
