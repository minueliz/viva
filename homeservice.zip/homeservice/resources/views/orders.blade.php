@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        @hasrole('admin')
            <div class="col-md-3">
                @include('layouts.sidebar')
            </div>
        <div class="col-md-9">
        @else
        <div class="col-md-12">
        @endhasrole
            <div class="card">
              @hasrole('admin')
                {{ Form::open(['url' => '/orders', 'method' => 'get', 'style' => 'width:100%', 'class' => 'mt-3 ml-3']) }}
                <fieldset class="search">
                    <div class="form-group row" style="line-height:35px">
                      <div class="col-md-3">
                        Type {!! Form::select('type', [0 => 'All', 1 => 'Products', 2 => 'Services'], $type, ['class' => 'form-control m-bot15 float-right', 'id' => 'cat', 'style' => 'width:auto']) !!}
                      </div>
                      <div class="col-md-5">
                        Status {!! Form::select('status', ['11' => 'All', 1 => 'Order placed', 2 => 'Shipped', 3 => 'Delivered', 0 => 'Worker notification sent', 7 => 'Worker confirmed order',
                            8 => 'User requested refund',
                            9 => 'Worker requested payment',
                            10 => 'Refunded', 4 => 'Invoice generated', 5 => 'Completed'], $status, ['class' => 'form-control m-bot15 float-right', 'id' => 'cat', 'style' => 'width:auto']) !!}
                      </div>
                      {{ Form::submit('Search', array('class' => 'btn btn-primary')) }}
                    </div>
                </fieldset>
                {{ Form::close() }}
              @endhasrole
                <div class="card-header">
                  @hasrole('admin')
                  @else
                    My
                  @endhasrole
                    Orders
                </div>

                <div class="card-body">
                    @if (session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                    @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif 
                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          <th scope="col">#ID</th>
                          <th scope="col">Name</th>
                          <th scope="col">Date</th>
                          <th scope="col">Shipping Address</th>
                          <th scope="col">Service Address</th>
                          <th scope="col">Amount</th>
                        </tr>
                      </thead>
                      <tbody>                        
                          @foreach($orders as $order)
                          <tr>
                            <td>
                              <a href="{{ URL::to('order-details/' . $order->id) }}">#{{ str_pad($order->id, 4, '0', STR_PAD_LEFT) }}</a>
                            </td>
                            <td>
                              {{ ucfirst($order->user->name) }}
                            </td>
                            <td>
                              {{ date('d-m-Y', strtotime($order->created_at)) }}
                            </td>
                            <td>
                              {!! ($order->shipping_address)?nl2br($order->shipping_address):'--' !!}  
                            </td>
                            <td>
                              {!! ($order->service_addr)?nl2br($order->service_addr):'--' !!}  
                            </td>
                            <td>{!! config('app.currency') !!}{{ number_format($order->amount, 2) }}</td>
                            </tr>
                          @endforeach
                          @if(!count($orders))
                            <tr class="no-rec">
                              <td colspan="6">No records!</td>
                            </tr>
                          @endif
                        </tbody>
                    </table>
                  {!! $orders->appends(\Request::except('page'))->render() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
<script type="text/javascript">
$(function(){
  setTimeout(function() {
                $('select[name="type"]').trigger('change');
            }, 100);

  $('select[name="type"]').change(function(){
    $('select[name="status"] option').removeAttr('disabled')
    if($('select[name="type"]').val() == '1'){
      $('select[name="status"] option[value="0"]').attr('disabled', 'disabled')
      $('select[name="status"] option[value="4"]').attr('disabled', 'disabled')
      $('select[name="status"] option[value="5"]').attr('disabled', 'disabled')
      $('select[name="status"] option[value="7"]').attr('disabled', 'disabled')
      $('select[name="status"] option[value="8"]').attr('disabled', 'disabled')
      $('select[name="status"] option[value="9"]').attr('disabled', 'disabled')
      $('select[name="status"] option[value="10"]').attr('disabled', 'disabled')
    } else if($('select[name="type"]').val() == '2'){
      $('select[name="status"] option[value="2"]').attr('disabled', 'disabled')
      $('select[name="status"] option[value="3"]').attr('disabled', 'disabled')
    }
  })  
});
</script>
@endsection