@extends('layouts.app')
@section('title', '| Edit Profile')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Edit Profile</div>

                <div class="card-body">
                  <!-- if there are creation errors, they will show here -->
                  @if ($errors->any())
                    <div class="alert alert-danger">
                      {{ Html::ul($errors->all()) }}
                    </div>
                  @endif
                  @if (session('success'))
                      <div class="alert alert-success">
                          {{ session('success') }}
                      </div>
                  @endif

                  {{ Form::model($userInfo, array('url' => array('edit-profile'), 'method' => 'POST', 'enctype' => 'multipart/form-data')) }}
                    <fieldset>

                      <div class="form-group row">
                          {{ Form::label('name', 'Name', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ Form::text('name', $userInfo->user->name, array('class' => 'form-control', 'placeholder' => "Ayanda")) }}
                          </div>
                      </div>

                      <div class="form-group row">
                          {{ Form::label('addr', 'Address', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ Form::textarea('addr', Request::old('addr'), array('class' => 'form-control', 'rows' => '3')) }}
                          </div>
                      </div>

                      <div class="form-group row">
                            {{ Form::label('did', 'District', array('class' => 'col-md-4 control-label text-md-right')) }}
                            <div class="col-md-4">
                              {!! Form::select('did', $districts, $userInfo->district_id, ['class' => $errors->has('did') ? 'form-control is-invalid' : 'form-control']) !!}
                            </div>
                      </div>

                      <div class="form-group row">
                          {{ Form::label('pin_code', 'Pin code', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ Form::text('pin_code', Request::old('pin_code'), array('class' => 'form-control')) }}
                          </div>
                      </div>

                      <div class="form-group row">
                          {{ Form::label('phone', 'Phone', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ Form::text('phone', Request::old('phone'), array('class' => 'form-control', 'placeholder' => "0764344899")) }}
                          </div>
                      </div>

                      <div class="form-group row">
                          {{ Form::label('alt_phone', 'Alternate phone', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ Form::text('alt_phone', Request::old('alt_phone'), array('class' => 'form-control', 'placeholder' => "0821234567")) }}
                          </div>
                      </div>
                    @if($worker)
                      <div class="form-group row">
                          {{ Form::label('scat', 'Service category', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {!! Form::select('scat', $categories, $userInfo->service_category, ['class' => $errors->has('scat') ? 'form-control is-invalid' : 'form-control']) !!}
                          </div>
                      </div>
                    @endif
                      <div class="form-group row">
                            {{ Form::label('sec_q', 'Security question', array('class' => 'col-md-4 control-label text-md-right')) }}
                            <div class="col-md-4">
                              {!! Form::select('sec_q', $sec_qs, $userInfo->sec_q, ['class' => $errors->has('sec_q') ? 'form-control is-invalid' : 'form-control']) !!}
                            </div>
                      </div>

                      <div class="form-group row">
                          {{ Form::label('sec_a', 'Answer', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ Form::text('sec_a', Request::old('sec_a'), array('class' => 'form-control')) }}
                          </div>
                      </div>

                      <div class="form-group row">
                          {{ Form::label('image', 'Profile picture', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ Form::file('image', array('class' => $errors->has('image') ? 'form-control is-invalid' : 'form-control')) }}
                          </div>
                      </div>
                    @if(!empty($userInfo->img))
                      <div class="form-group row offset-md-4">
                        <div class="col-md-4">
                          <img class="profilepic" src="{{URL::asset('images/profile')}}/{{$userInfo->img}}">
                        </div>
                      </div>
                    @endif
                      @if($worker)
                            <div class="form-group row">
                                {{ Form::label('exp_proof', 'Experience proof', array('class' => 'col-md-4 control-label text-md-right')) }}
                                <div class="col-md-4">
                                  {{ Form::file('exp_proof', array('class' => $errors->has('exp_proof') ? 'form-control is-invalid' : 'form-control')) }}
                                </div>
                            </div>
                          
                            <div class="form-group row offset-md-4">
                              <div class="col-md-4">
                                <img class="profilepic" src="{{URL::asset('images/proofs')}}/{{$userInfo->exp_proof}}">
                              </div>
                            </div>
                          
                            <div class="form-group row">
                                {{ Form::label('id_proof', 'Identity proof', array('class' => 'col-md-4 control-label text-md-right')) }}
                                <div class="col-md-4">
                                  {{ Form::file('id_proof', array('class' => $errors->has('id_proof') ? 'form-control is-invalid' : 'form-control')) }}
                                </div>
                            </div>
                          
                            <div class="form-group row offset-md-4">
                              <div class="col-md-4">
                                <img class="profilepic" src="{{URL::asset('images/proofs')}}/{{$userInfo->id_proof}}">
                              </div>
                            </div>

                            <div class="form-group row">
                                {{ Form::label('per_hour_amount', 'Per hour amount', array('class' => 'col-md-4 control-label text-md-right')) }}
                                <div class="col-md-4">
                                  {{ Form::number('per_hour_amount', Request::old('per_hour_amount'), array('class' => 'form-control', 'min' => 1, 'max' => 999)) }}
                                </div>
                            </div>
                      @endif

                      <div class="form-group row">
                        <div class="col-md-4 offset-md-4">
                          {{ Form::submit('Save', array('class' => 'btn btn-primary')) }}
                        </div>
                      </div>
                    </fieldset>
                  {{ Form::close() }}
                </div>
            </div>
        </div>
    </div>
</div> 
@endsection