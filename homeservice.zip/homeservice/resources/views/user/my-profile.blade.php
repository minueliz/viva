@extends('layouts.app')
@section('title', '| User Profile')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">{{ Request::is('profile/*') ? 'User' : 'My' }} Profile</div>

                <div class="card-body">
                  
                    <div class="form-group row">
                        {{ Form::label('name', 'Name', array('class' => 'col-md-4 control-label text-md-right')) }}
                        <div class="col-md-4">
                          {{ $userInfo->user->name }}
                        </div>
                    </div>

                    <div class="form-group row">
                        {{ Form::label('addr', 'Address', array('class' => 'col-md-4 control-label text-md-right')) }}
                        <div class="col-md-4">
                          {{ $userInfo->addr }}
                        </div>
                    </div>

                    <div class="form-group row">
                          {{ Form::label('did', 'District', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ $userInfo->district->district }}
                          </div>
                    </div>

                    <div class="form-group row">
                        {{ Form::label('pin_code', 'Pin code', array('class' => 'col-md-4 control-label text-md-right')) }}
                        <div class="col-md-4">
                          {{ $userInfo->pin_code }}
                        </div>
                    </div>

                    <div class="form-group row">
                        {{ Form::label('phone', 'Phone', array('class' => 'col-md-4 control-label text-md-right')) }}
                        <div class="col-md-4">
                          {{ $userInfo->phone }}
                        </div>
                    </div>

                    <div class="form-group row">
                        {{ Form::label('alt_phone', 'Alternate phone', array('class' => 'col-md-4 control-label text-md-right')) }}
                        <div class="col-md-4">
                          {{ empty($userInfo->alt_phone)?'-':$userInfo->alt_phone }}
                        </div>
                    </div>
                  @if($worker)
                    <div class="form-group row">
                        {{ Form::label('scat', 'Service category', array('class' => 'col-md-4 control-label text-md-right')) }}
                        <div class="col-md-4">
                          {{ $userInfo->category->category }}
                        </div>
                    </div>
                  @endif
                    <div class="form-group row">
                          {{ Form::label('sec_q', 'Security question', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ $userInfo->sec_question->question }}
                          </div>
                    </div>

                    <div class="form-group row">
                        {{ Form::label('sec_a', 'Answer', array('class' => 'col-md-4 control-label text-md-right')) }}
                        <div class="col-md-4">
                          {{ $userInfo->sec_a }}
                        </div>
                    </div>
                    
                    @if(!empty($userInfo->img))
                      <div class="form-group row">
                        {{ Form::label('sec_a', 'Profile image', array('class' => 'col-md-4 control-label text-md-right')) }}
                        <div class="col-md-4">
                          <img class="profilepic" src="{{URL::asset('images/profile')}}/{{$userInfo->img}}">
                        </div>
                      </div>
                    @endif
                    
                    @if($worker)
                      <div class="form-group row">
                        {{ Form::label('sec_a', 'Experience proof', array('class' => 'col-md-4 control-label text-md-right')) }}
                        <div class="col-md-4">
                          <a target="_blank" href="{{URL::asset('images/proofs')}}/{{$userInfo->exp_proof}}">
                            <img class="profilepic" src="{{URL::asset('images/proofs')}}/{{$userInfo->exp_proof}}">
                          </a>
                        </div>
                      </div>
                    
                      <div class="form-group row">
                        {{ Form::label('sec_a', 'Address proof', array('class' => 'col-md-4 control-label text-md-right')) }}
                        <div class="col-md-4">
                          <a target="_blank" href="{{URL::asset('images/proofs')}}/{{$userInfo->id_proof}}">
                            <img class="profilepic" src="{{URL::asset('images/proofs')}}/{{$userInfo->id_proof}}">
                          </a>
                        </div>
                      </div>

                      <div class="form-group row">
                        {{ Form::label('amt', 'Per hour amount', array('class' => 'col-md-4 control-label text-md-right')) }}
                        <div class="col-md-4">
                          {{ number_format($userInfo->per_hour_amount, 2) }}
                        </div>
                      </div>
                    @endif

                </div>
            </div>
        </div>
    </div>
</div> 
@endsection