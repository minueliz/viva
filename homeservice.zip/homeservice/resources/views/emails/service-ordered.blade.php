@component('mail::message')
Dear {{ $name }},

User <b>{{ $details['custName'] }}</b> has ordered your service <a href="{{ URL::to('service-requests/'. $details['item_id'])}} }}">#{{ $details['item_id'] }}</a>. Find below the details,<br>
Date: {{ $details['bDate'] }}<br>
Category: {{ $details['catName'] }}<br>
Subcategory: {{ $details['subCatName'] }}<br>
Slot: {{ $details['slotName'] }}<br>
Description: {!! nl2br($details['desc']) !!}<br>
Image: <img src="{{ URL::asset('images/serv')}}/{{$details['img'] }}"><br><br>
<b>PS: You have to respond by confirming or declining the request within a day, otherwise the request will be cancelled automatically.<b>


Thanks,<br>
{{ config('app.name') }}
@endcomponent