@component('mail::message')
Dear {{ $name }},

User <b>{{ $service->worker->name }}</b> has rejected the service request, #<b><a href="{{ URL::to('order-details/' . $service->order->id) }}">{{ $service->order->id }}</a></b>. 

Thanks,<br>
{{ config('app.name') }}
@endcomponent