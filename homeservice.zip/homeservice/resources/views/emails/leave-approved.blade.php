@component('mail::message')
Dear {{ $name }},

Your leave for {{ $duration }} has been {{ $stat }} by Administrator.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
