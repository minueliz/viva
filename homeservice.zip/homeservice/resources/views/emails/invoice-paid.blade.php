@component('mail::message')
Dear {{ $name }},

User <b>{{ $invoice->service->order->user->name }}</b> has paid for the invoice for order, #<b><a href="{{ URL::to('service-requests/' . $service->id) }}">{{ $service->id }}</a></b>. 
Find below the details,<br>
Date: {{ date('d-m-Y') }}<br>
Total: {!! config('app.currency') !!}{{ number_format($service->amount, 2) }}<br>
Commission: {!! config('app.currency') !!}{{ number_format($service->commision, 2) }}<br>

Thanks,<br>
{{ config('app.name') }}
@endcomponent