@extends('layouts.app')
@section('title', '| Add New Product')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            @include('layouts.sidebar')
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Add Service Category</div>

                <div class="card-body">
                  <!-- if there are creation errors, they will show here -->
                  @if ($errors->any())
                    <div class="alert alert-danger">
                      {{ Html::ul($errors->all()) }}
                    </div>
                  @endif

                  {{ Form::open(array('url' => 'service-categories', 'enctype' => 'multipart/form-data')) }}
                    <div class="lds-dual-ring"></div>
                    <fieldset>
                      @if(!is_null($slug))
                        {{ Form::hidden('subcat', '1') }}
                        <div class="form-group row inserted">
                            {{ Form::label('pcategory', 'Category', array('class' => 'col-md-4 control-label text-md-right')) }}
                            <div class="col-md-4">
                              {!! Form::select('pcategory', $categories, null, ['class' => 'form-control']) !!}
                            </div>
                        </div>
                      @endif
                      <div class="form-group row">
                        @if(!is_null($slug))
                          {{ Form::label('category', 'Subcategory Name', array('class' => 'col-md-4 control-label text-md-right')) }}
                        @else
                          {{ Form::label('category', 'Category Name', array('class' => 'col-md-4 control-label text-md-right')) }}
                        @endif
                          <div class="col-md-4">
                            {{ Form::text('category', Request::old('category'), array('class' => 'form-control')) }}
                          </div>
                      </div>

                      <div class="form-group row">
                            {{ Form::label('image', 'Image', array('class' => 'col-md-4 control-label text-md-right')) }}
                            <div class="col-md-4">
                              {{ Form::file('image', array('class' => $errors->has('image') ? 'form-control is-invalid' : 'form-control')) }}
                            </div>
                      </div>

                      <div class="form-group row">
                        <div class="col-md-4 offset-md-4">
                          {{ Form::submit('Save', array('class' => 'btn btn-primary')) }}
                        </div>
                      </div>
                    </fieldset>
                  {{ Form::close() }}
                </div>
            </div>
        </div>
    </div>
</div> 
@endsection