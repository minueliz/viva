@extends('layouts.app')
@section('title', '| Edit District')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            @include('layouts.sidebar')
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Edit Security Question</div>

                <div class="card-body">
                  <!-- if there are creation errors, they will show here -->
                  @if ($errors->any())
                    <div class="alert alert-danger">
                      {{ Html::ul($errors->all()) }}
                    </div>
                  @endif

                  {{ Form::model($sec_question, array('route' => array('security-questions.update', $sec_question->id), 'method' => 'PUT')) }}
                    <fieldset>
                      <div class="form-group row">
                          {{ Form::label('question', 'Security Question', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ Form::text('question', Request::old('question'), array('class' => 'form-control')) }}
                          </div>
                      </div>

                      <div class="form-group row">
                        <div class="col-md-4 offset-md-4">
                          {{ Form::submit('Save', array('class' => 'btn btn-primary')) }}
                        </div>
                      </div>
                    </fieldset>
                  {{ Form::close() }}
                </div>
            </div>
        </div>
    </div>
</div> 
@endsection