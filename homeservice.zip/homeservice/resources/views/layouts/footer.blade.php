<section class="footer">
	<div class="container">
	     <div class="wrapper">
			<ul class="social-icons icon-circle icon-zoom list-unstyled list-inline social"> 
				<li> <a href="#"><i class="fab fa-facebook-f"></i></a></li> 
				<li> <a href="#"><i class="fab fa-twitter"></i></a></li> 
				<li> <a href="#"><i class="fab fa-linkedin-in"></i></a></li>
			</ul>
		</div>
		<div class="copyright">
			<p>
				&copy; {{ Carbon::now()->format("Y") }} {{ config('app.name', 'Laravel') }}. All Rights Reserved.
			</p>			
		</div>
	</div>
</section>