<nav class="navbar navbar-expand-md side-navbar">
    <div class="container">        
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContentSub" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContentSub">
            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav">
                <!-- Authentication Links -->
                @role('admin')
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('admin') }}">{{ __('Dashboard') }}</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            {{ __('Users') }} <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="{{ url('admin/users') }}">
                                {{ __('Customers') }}
                            </a>

                            <a class="dropdown-item" href="{{ url('admin/workers') }}">
                                {{ __('Workers') }}
                            </a>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            {{ __('Products') }} <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="{{ url('products') }}">
                                {{ __('List') }}
                            </a>

                            <a class="dropdown-item" href="{{ url('products/create') }}">
                                {{ __('Add') }}
                            </a>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            {{ __('Product Categories') }} <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="{{ url('product-categories') }}">
                                {{ __('List') }}
                            </a>

                            <a class="dropdown-item" href="{{ url('product-categories/create') }}">
                                {{ __('Add') }}
                            </a>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            {{ __('Service Categories') }} <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="{{ url('service-categories') }}">
                                {{ __('List Categories') }}
                            </a>

                            <a class="dropdown-item" href="{{ url('service-categories/create') }}">
                                {{ __('Add Category') }}
                            </a>
                            <a class="dropdown-item" href="{{ url('service-categories/subcategories/list') }}">
                                {{ __('List Subcategories') }}
                            </a>

                            <a class="dropdown-item" href="{{ url('service-categories/create/sub') }}">
                                {{ __('Add Subategory') }}
                            </a>
                        </div>
                    </li>
                    <!-- <li class="nav-item">
                        <a class="nav-link" href="{{ url('service-slots') }}">
                            {{ __('Service Slots') }}
                        </a>
                    </li> -->
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            {{ __('Districts') }} <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="{{ url('districts') }}">
                                {{ __('List') }}
                            </a>

                            <a class="dropdown-item" href="{{ url('districts/create') }}">
                                {{ __('Add') }}
                            </a>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            {{ __('Security Questions') }} <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="{{ url('security-questions') }}">
                                {{ __('List') }}
                            </a>

                            <a class="dropdown-item" href="{{ url('security-questions/create') }}">
                                {{ __('Add') }}
                            </a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('orders') }}">
                            {{ __('Orders') }}
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('reviews') }}">
                            {{ __('Reviews') }}
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('leaves') }}">
                            {{ __('Leaves') }}
                            @if($leaveCount)
                                <span class="fa-stack fa-1x has-badge" data-count="{{ $leaveCount }}">
                                    <i class="fa fa-circle fa-stack-2x"></i>
                                    <i class="fa fa-bell fa-stack-1x fa-inverse"></i>
                                </span>
                            @endif
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('commission') }}">
                            {{ __('Commission') }}
                        </a>
                    </li>
                @endif  
            </ul>
        </div>
    </div>
</nav>