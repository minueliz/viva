@extends('layouts.app')
@section('title', '| Product')

@section('content')
<div class="container">
	<!-- if there are creation errors, they will show here -->
	@if ($errors->any())
		<div class="alert alert-danger">
		  {{ Html::ul($errors->all()) }}
		</div>
	@endif
	@if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
    <div class="row justify-content-center single-prod">        
	   <div class="col-md-6">
	   	@if(!empty($product->img))
		  <img class="img-responsive" src="{{URL::asset('images/products')}}/{{$product->img}}" >
		@else
		  <img class="img-responsive" src="{{URL::asset('images/products')}}/214x150.png" >
		@endif
	   </div>
	   <div class="col-md-6">
	   	<div class="col-md-12">
		 <h1>{{ $product->name }}</h1>
		</div>
		<div class="row">
		 <div class="col-md-12">
		  <!-- <p class="description">
		   Classic film camera. Uses 620 roll film.
		   Has a 2&frac14; x 3&frac14; inch image size.
		  </p> -->
		 </div>
		</div><!-- end row -->

		<div class="row">
		 <div class="col-md-4">
		  <!-- <span class="sr-only">Four out of Five Stars</span> -->
		  @for($i=1; $i<=$rating; $i++)
		  	<span class="fas fa-star" aria-hidden="true"></span>
		  <!-- <span class="label label-success">61</span> -->
		  @endfor
		  @for($i=$rating; $i<5; $i++)
		  	<span class="far fa-star" aria-hidden="true"></span>
		  <!-- <span class="label label-success">61</span> -->
		  @endfor
		 </div>
		</div><!-- end row -->

		<div class="row">
		 <div class="col-md-12 bottom-rule">
		  <h2 class="product-price">{!! config('app.currency') !!}{{ number_format($product->amount, 2) }}</h2>
		 </div>
		</div><!-- end row -->
		@if($product->qty)
			{{ Form::open(array('url' => 'cart/' . $product->id, 'class' => 'pull-right')) }}
				<div class="row add-to-cart">
				 <div class="col-md-5 product-qty">
				  {{ Form::number('qty'.$product->id, 1, array('class' => 'btn btn-default btn-lg btn-qty', 'min' => 1, 'max' => 999)) }}
		          {{ Form::hidden('_method', 'POST') }}
				 </div>
				 <div class="col-md-4">
				  {{ Form::submit('Add to Cart', array('class' => 'btn btn-lg btn-brand btn-full-width')) }}
				 </div>
				</div><!-- end row -->
			{{ Form::close() }}

			<div class="row">
			 <div class="col-md-5 text-center">
			  <span>In Stock</span>
			 </div>
			</div><!-- end row -->
		@else
			<div class="row">
			 <div class="col-md-5">
			<span class="out-of-stock">Out of stock</span>
			 </div>
			</div><!-- end row -->
		@endif
		<div class="row">
		 <div class="col-md-12 bottom-rule mt-2"></div>
		</div><!-- end row -->

		<!-- Nav tabs -->
		<ul class="nav nav-tabs">
		  <li class="nav-item">
		    <a class="nav-link" href="#description" data-toggle="tab" role="tab" aria-controls="description" aria-selected="true">Description</a>
		  </li>
		  <li class="nav-item">
		    <a class="nav-link" href="#reviews" data-toggle="tab" role="tab" aria-controls="reviews" aria-selected="false">Reviews</a>
		  </li>
		</ul>
		<!-- Tab panes -->
		<div class="tab-content">
		 <div role="tabpanel" class="tab-pane fade show" id="description">
		 	<p class="mt-2">
				{{ $product->description }}  
			</p>
		 </div>
		 <div role="tabpanel" class="tab-pane mt-2 fade" id="reviews">
		 	@if(count($reviews))
		 		@foreach($reviews as $key => $review)
				  	<div class="row {{ (($key+1) < count($reviews)) ? 'border-bottom' : '' }} mb-2">
		        	    <div class="col-md-2">
		        	        @if(!empty($review->user->userinformation->img))
		                        <div class="inset">
		                          <img src="{{URL::asset('images/profile')}}/{{ $review->user->userinformation->img }}">
		                        </div>
		                    @else
		        	        	<img src="{{URL::asset('images/profile')}}/" class="img img-rounded img-fluid"/>
		                    @endif
		        	        <!-- <p class="text-secondary text-center">15 Minutes Ago</p> -->
		        	    </div>
		        	    <div class="col-md-10">
		        	        <p>
		        	            <a class="float-left namel" href="#"><strong>{{ ucfirst($review->user->name) }}</strong></a>
		        	            @for($i=$rating; $i<5; $i++)
									<span class="float-right"><span class="text-warning far fa-star" aria-hidden="true"></span></span>
								@endfor
		        	            @for($i=1; $i<=$rating; $i++)
							  		<span class="float-right"><i class="text-warning fa fa-star"></i></span>
								@endfor
		        	       </p>
		        	       <div class="clearfix"></div>
		        	        <p>{{ $review->comment }}</p>
		        	    </div>
			        </div>
			    @endforeach
		    @else
		    	<div class="row">
		    		No reviews yet!
		    	</div>
		    @endif
		  	{!! $reviews->appends(['tab' => 'review'])->render() !!}
		 </div>
		</div>
	   </div>
	</div>
	@if(count($relatedProducts))
	<div class="row mt-5">
        <div class="col-md-12">
          <h3>Related Products</h3>
          <div class="owl-carousel products carousel mt-3 mb-4">
              @foreach($relatedProducts as $product)
                <div class="item">
                  <a href="{{ URL::to('product/' .  Str::slug($product->name) . '/' . $product->id) }}">
                      @if(!empty($product->img))
                          <img src="{{URL::asset('images/products')}}/{{$product->img}}" >
                      @else
                          <img src="{{URL::asset('images/products')}}/214x150.png" >
                      @endif
                  </a>
                  <div class="cat-name">{{ $product->name }}</div>
                </div>
              @endforeach
            </div>
        </div>
    </div>
    @endif
</div> 
@endsection
<link rel="stylesheet" href="{{ asset('css/owl.carousel.min.css') }}">
@section('scripts')
<script src="{{ asset('js/owl.carousel.js') }}"></script>
<script type="text/javascript">
	$( document ).ready(function() {
		$('.carousel').owlCarousel({
              loop:true,
              margin:10,
              nav:false,
              autoplay: true,
              autoHeight:true,
              responsive:{
                  0:{
                      items:2
                  },
                  600:{
                      items:3
                  },
                  1000:{
                      items:5
                  }
              }
        })

		if(window.location.href.indexOf('tab=review') > -1) {
			$('a[aria-controls="reviews"]').trigger('click')
		} else 
			$('a[aria-controls="description"]').trigger('click')
	})
</script>
@endsection